"""Independent model references and aggregate benchmark metadata stay out of estimation."""
import copy,hashlib,json
from pathlib import Path
import unittest
from unittest.mock import patch
import causalengine
from causalengine import Editor

GRAPH={'nodes':[{'name':'A','family':'binary'},{'name':'Y','family':'linear'}],'edges':[['A','Y']]}
QUERY={'type':'interventional','summary':'mean_difference','targets':['Y'],'intervention':{'A':1},'reference':{'A':0},'Z':[],'n':2048,'max_seconds':10}
def setup(family='linear',seed=5):
 graph=copy.deepcopy(GRAPH);graph['nodes'][1]['family']=family
 editor=Editor();built=editor.request('build',dict(graph,model_seed=7,noise='normal'))
 sampled=editor.request('sample',dict(token=built['token'],n=512,data_seed=seed))
 return editor,graph,built,sampled

def reference(editor,graph,built,sampled,**query):
 return editor.request('sample_reference',dict(graph,source='random',token=built['token'],sample_id=sampled['sample_id'],**dict(QUERY,**query)))

class GroundTruthTests(unittest.TestCase):
 def test_exact_reference_contrast_seed_and_sample_are_preserved(self):
  e,g,b,s=setup();before=e._sample.copy(deep=True)
  out=reference(e,g,b,s);reverse=reference(e,g,b,s,intervention={'A':0},reference={'A':1});same=reference(e,g,b,s,intervention={'A':1},reference={'A':1})
  self.assertEqual(out['reference_kind'],'exact_model_mean');self.assertFalse(out['model_reference']['approximate'])
  self.assertEqual(out['source_seed'],5);self.assertEqual(out['reference_seed'],5^0xA5A5A5A5)
  self.assertEqual(out['model_reference']['values']['Y'],-reverse['model_reference']['values']['Y'])
  self.assertEqual(same['model_reference']['values']['Y'],0)
  self.assertTrue(before.equals(e._sample));self.assertEqual(e.sample_id,s['sample_id']);self.assertEqual(e.token,b['token'])
  self.assertEqual(e._sample.to_csv(index=False,float_format='%.17g'),s['csv'])
  second=e.request('sample',dict(token=b['token'],n=512,data_seed=5));self.assertEqual(second['csv'],s['csv'])
  self.assertEqual(reference(e,g,b,second)['model_reference']['values'],out['model_reference']['values'])

 def test_nonlinear_reference_is_monte_carlo_and_reuses_generation(self):
  e,g,b,s=setup('bounded',seed=31);before=e._sample.copy(deep=True)
  a=reference(e,g,b,s);other=reference(e,g,b,s)
  self.assertEqual(a['reference_kind'],'monte_carlo_model_mean');self.assertTrue(a['model_reference']['approximate'])
  self.assertEqual(a['model_reference']['status'],'OK');self.assertEqual(a['model_reference']['values'],other['model_reference']['values'])
  self.assertEqual(a['model_reference']['query']['data_seed'],31^0xA5A5A5A5)
  self.assertEqual(a['reference_draws'],2048);self.assertTrue(before.equals(e._sample))

 def test_reference_guards_source_generation_graph_schema_and_query(self):
  e,g,b,s=setup();payload=dict(g,source='random',token=b['token'],sample_id=s['sample_id'],**QUERY)
  for changes,message in [({'source':'csv'},'only for Random'),({'token':999},'model expired'),({'sample_id':999},'sample expired'),({'edges':[]},'graph or variable types')]:
   with self.subTest(changes=changes),self.assertRaisesRegex(ValueError,message):e.request('sample_reference',dict(payload,**changes))
  changed=copy.deepcopy(payload);changed['nodes'][1]['family']='binary'
  with self.assertRaisesRegex(ValueError,'variable types'):e.request('sample_reference',changed)
  for changes in [{'type':'counterfactual'},{'targets':['A','Y']},{'evidence':{'Y':0}}]:
   with self.subTest(changes=changes):self.assertEqual(e.request('sample_reference',dict(payload,**changes))['reference_kind'],'unavailable')
  with self.assertRaisesRegex(ValueError,'binary action'):e.request('sample_reference',dict(payload,intervention={'A':2}))
  e.request('sample',dict(token=b['token'],n=512,data_seed=6))
  with self.assertRaisesRegex(ValueError,'sample expired'):e.request('sample_reference',payload)

 def test_truth_assets_are_aggregate_and_factual_tables_unchanged(self):
  root=Path(causalengine.__file__).parent/'web/benchmarks';manifest=json.loads((root/'manifest.json').read_text());truth=json.loads((root/'ground-truth.json').read_text())
  expected={'ihdp':4.016066896118338,'acic':2.1280792580310415}
  for dataset in manifest['datasets']:
   ref=truth['datasets'][dataset['id']];data=(root/dataset['csv']).read_bytes()
   self.assertEqual(hashlib.sha256(data).hexdigest(),ref['factual_sha256']);self.assertEqual(ref['n'],dataset['rows'])
   self.assertEqual(dataset['ground_truth']['key'],dataset['id']);self.assertNotIn('mu0',data.splitlines()[0].decode());self.assertNotIn('mu1',data.splitlines()[0].decode())
   if dataset['id']in expected:
    self.assertAlmostEqual(ref['value'],expected[dataset['id']],places=13);self.assertEqual(ref['target'],'released_row_mean_conditional_effect');self.assertFalse(ref['population_ate'])
   else:self.assertEqual(ref['status'],'UNAVAILABLE');self.assertNotIn('value',ref)
   self.assertNotIn('unit_truth',ref);self.assertNotIn('mu0',ref);self.assertNotIn('mu1',ref)

if __name__=='__main__':unittest.main()
