"""Existing binary-vector Random DGP presets, actual queries and snapshot reuse."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

from causalengine import Editor
import causalengine.balancing_aipw as core


def configuration(dimension, outcome="linear"):
    action = {"name": "A", "observed": True, "dimension": dimension, "family": "binary"}
    if dimension > 1:
        action["members"] = [f"a{i + 1}" for i in range(dimension)]
    return {
        "nodes": [{"name": "X", "family": "linear"}, action, {"name": "Y", "family": outcome}],
        "edges": [["X", "A"], ["X", "Y"], ["A", "Y"]],
        "model_seed": 7, "noise": "normal",
        "random_cluster_sizes": {"X": 2}, "random_cluster_members": {"X": ["x1", "x2"]},
    }


class RandomConfigurationTests(unittest.TestCase):
    cases = {}
    report = {"fixed_settings": {"model_seed": 7, "data_seed": 5, "rows": 5000, "X_dimension": 2}, "cases": {}}

    @classmethod
    def setUpClass(cls):
        for dimension, family in [(2, "linear"), (3, "linear"), (4, "linear"), (2, "quadratic"), (2, "bounded")]:
            key = f"A{dimension}-{family}"
            graph = configuration(dimension, family)
            editor = Editor()
            built = editor.request("build", copy.deepcopy(graph))
            sample = editor.request("sample", {"token": built["token"], "random_key": built["random_key"], "n": 5000, "data_seed": 5})
            frame = pd.read_csv(io.StringIO(sample["csv"]))
            query = dict(graph, source="random", token=built["token"], sample_id=sample["sample_id"], random_key=built["random_key"],
                         type="interventional", targets=["Y"], intervention={"A": [1 if i % 2 == 0 else 0 for i in range(dimension)]},
                         n=512, max_seconds=10)
            cls.cases[key] = (editor, graph, built, sample, frame, query)
            cls.report["cases"][key] = {"build_payload": graph, "columns": sample["columns"], "shape": sample["shape"],
                "csv_sha256": hashlib.sha256(sample["csv"].encode()).hexdigest(), "model": built["model"],
                "joint_class_counts": {"".join(map(str, a)): int(count) for a, count in zip(*np.unique(frame[[f"a{i + 1}" for i in range(dimension)]].to_numpy(dtype=int), axis=0, return_counts=True))},
                "queries": {}}

    @classmethod
    def tearDownClass(cls):
        if os.environ.get("RANDOM_CONFIG_REPORT"):
            Path(os.environ["RANDOM_CONFIG_REPORT"]).write_text(json.dumps(cls.report, indent=2) + "\n")

    def run_query(self, key, method, estimand):
        editor, graph, built, sample, frame, original = self.cases[key]
        query = copy.deepcopy(original)
        query.update(estimation_method=method, estimand=estimand, summary="mean" if estimand == "apo" else "mean_difference")
        if estimand == "ate":
            query["reference"] = {"A": [0] * len(query["intervention"]["A"])}
        data_before = editor._sample.copy(deep=True)
        result = editor.request("estimate_data", query)
        self.assertTrue(editor._sample.equals(data_before))
        self.assertEqual(result["token"], built["token"])
        self.assertEqual(result["sample_id"], sample["sample_id"])
        self.assertEqual(result["random_key"], built["random_key"])
        estimate = result["data_estimate"]
        self.report["cases"][key]["queries"][method + "-" + estimand] = estimate
        return query, estimate

    def assert_success(self, key, method, estimand):
        query, estimate = self.run_query(key, method, estimand)
        self.assertEqual(estimate["status"], "OK", estimate)
        self.assertTrue(np.isfinite(estimate["values"]["Y"]))
        details = estimate["estimation_details"]
        self.assertEqual(details["options"]["estimand"], estimand)
        self.assertEqual(details["inputs"]["intervention"], query["intervention"]["A"])
        self.assertEqual(details["inputs"]["treatment_members"], self.cases[key][3]["columns"][2:-1])
        self.assertEqual(details["inputs"]["reference"], query.get("reference", {}).get("A"))
        calls = {"aipw": {"outcome": 2 if estimand == "apo" else 4, "weights": 2 if estimand == "apo" else 4, "propensity": 0},
                 "outcome_regression": {"outcome": 2 if estimand == "apo" else 4, "weights": 0, "propensity": 0},
                 "ipw": {"outcome": 0, "weights": 0, "propensity": 2}}[method]
        self.assertEqual(details["nuisance"]["fit_calls"], calls)

    def test_two_and_three_binary_members_actual_three_methods_ate_apo(self):
        for dimension in (2, 3):
            for method in ("aipw", "outcome_regression", "ipw"):
                for estimand in ("ate", "apo"):
                    with self.subTest(dimension=dimension, method=method, estimand=estimand):
                        self.assert_success(f"A{dimension}-linear", method, estimand)

    def test_other_outcome_families_and_offered_four_members_actual_ipw(self):
        with patch.object(core, "fit_xgboost_mean", side_effect=AssertionError("IPW cannot fit outcome regression")):
            for key in ("A2-quadratic", "A2-bounded", "A4-linear"):
                with self.subTest(configuration=key):
                    self.assert_success(key, "ipw", "apo")

    def test_rows_members_seed_replay_and_snapshot_guards(self):
        for key, (editor, graph, built, sample, frame, query) in self.cases.items():
            dimension = len(query["intervention"]["A"])
            members = [f"a{i + 1}" for i in range(dimension)]
            with self.subTest(configuration=key):
                self.assertEqual(sample["columns"], ["x1", "x2", *members, "Y"])
                self.assertEqual(sample["shape"], [5000, dimension + 3])
                self.assertEqual(list(frame.columns), sample["columns"])
                self.assertEqual(len(frame), 5000)
                self.assertTrue(np.isin(frame[members].to_numpy(), [0, 1]).all())
                self.assertEqual(built["model"]["variables"]["A"]["shape"], (dimension,))
                fresh = Editor()
                rebuilt = fresh.request("build", copy.deepcopy(graph))
                regenerated = fresh.request("sample", {"token": rebuilt["token"], "random_key": rebuilt["random_key"], "n": 5000, "data_seed": 5})
                self.assertEqual(regenerated["csv"], sample["csv"])
                self.assertEqual(rebuilt["model"], built["model"])
        editor, graph, built, sample, frame, query = self.cases["A3-linear"]
        changed = copy.deepcopy(query)
        changed.update(estimation_method="ipw", estimand="apo", summary="mean")
        changed["nodes"][1]["members"] = ["a2", "a1", "a3"]
        with self.assertRaisesRegex(ValueError, "graph"):
            editor.request("estimate_data", changed)
        invalid = configuration(9)
        with self.assertRaisesRegex(ValueError, "dimension"):
            Editor().request("build", invalid)

    def test_vector_reference_is_actual_requested_world_and_preserves_rows(self):
        for key in ("A2-linear", "A3-linear", "A4-linear", "A2-quadratic", "A2-bounded"):
            editor, graph, built, sample, frame, original = self.cases[key]
            for estimand in (("ate", "apo") if key in ("A2-linear", "A3-linear") else ("apo",)):
                query = copy.deepcopy(original)
                query.update(estimand=estimand, summary="mean" if estimand == "apo" else "mean_difference")
                if estimand == "ate":
                    query["reference"] = {"A": [0] * len(query["intervention"]["A"])}
                before = editor._sample.copy(deep=True)
                answer = editor.request("sample_reference", query)
                result = answer["model_reference"]
                self.assertEqual(result["status"], "OK", result)
                self.assertEqual(result["query"]["intervention"], query["intervention"])
                self.assertEqual(result["query"]["reference"], query.get("reference"))
                self.assertEqual(answer["token"], built["token"])
                self.assertEqual(answer["sample_id"], sample["sample_id"])
                self.assertTrue(editor._sample.equals(before))
                seed = answer["reference_seed"]
                worlds = editor.model.sample_interventional(query["intervention"], 512, seed=seed)["Y"].to_numpy()
                if estimand == "ate":
                    worlds = worlds - editor.model.sample_interventional(query["reference"], 512, seed=seed)["Y"].to_numpy()
                self.assertAlmostEqual(result["values"]["Y"], float(worlds.mean()), places=12)
                self.report["cases"][key].setdefault("model_reference", {})[estimand] = answer
