import copy
import unittest
from unittest.mock import patch
import pandas as pd
import numpy as np
from causalengine import Editor,analyze,graph_examples
from causalengine.editor_engine import _categorical_feature_view
from causalengine.identification_engine import _graph,_observational_trace_tree
from causalengine import graph as graph_module
from causalengine import identify
from causalengine import indexed_identification as ii

class BenchmarkAdapterTests(unittest.TestCase):
    def test_100_scalar_columns_load_without_losing_any(self):
        columns=['V'+str(i) for i in range(100)]
        graph={'nodes':[{'name':c}for c in columns],'edges':[]}
        e=Editor();ready=e.request('load_data',dict(graph,columns=columns,rows=[[float(i)for i in range(100)]],mapping={c:c for c in columns}))
        self.assertEqual(ready['columns'],columns)
        self.assertEqual(e._uploaded['data'].shape,(1,100))
        bad=copy.deepcopy(graph);bad['nodes'].append({'name':'Extra'})
        with self.assertRaises(ValueError):e.request('load_data',dict(bad,columns=columns,rows=[[0]*100],mapping={c:c for c in columns}))

    def test_full_onehot_is_lossless_and_does_not_mutate_original(self):
        data=pd.DataFrame({'A':[0,1,0,1,0,1],'C':[100,200,900,100,200,900],'Y':[1,2,3,4,5,6], '__onehot__C_0':[77]*6})
        original=data.copy(deep=True)
        schema={c:{'shape':(),'columns':[c],'type':'categorical'if c=='C'else'binary'if c=='A'else'continuous'}for c in ['A','C','Y']}
        original_schema=copy.deepcopy(schema)
        view,meta,info=_categorical_feature_view(data,schema,{'categorical_encoding':'one_hot','intervention':{'A':1},'reference':{'A':0},'targets':['Y']})
        pd.testing.assert_frame_equal(data,original)
        self.assertEqual(schema,original_schema)
        self.assertEqual(len(view),len(data))
        self.assertEqual(meta['C']['shape'],(3,))
        self.assertEqual(info['encodings']['C']['codes'],[100.,200.,900.])
        cols=meta['C']['columns'];self.assertEqual(len(cols),3)
        self.assertNotIn('__onehot__C_0',cols)
        self.assertTrue((view['__onehot__C_0']==77).all())
        self.assertTrue((view[cols].sum(axis=1)==1).all())
        decoded=np.asarray(info['encodings']['C']['codes'])[view[cols].to_numpy().argmax(axis=1)]
        np.testing.assert_array_equal(decoded,data.C.to_numpy())
        self.assertNotIn('C',cols)

    def test_onehot_allocation_bound_rejects_without_pooling(self):
        data=pd.DataFrame({"A":[0]*101,"C":list(range(101)),"Y":[1]*101})
        original=data.copy(deep=True)
        schema={c:{"shape":(),"columns":[c],"type":"categorical"if c=="C"else"continuous"}for c in data}
        with self.assertRaisesRegex(ValueError,"no categories were dropped"):
            _categorical_feature_view(data,schema,{"categorical_encoding":"one_hot","targets":["Y"],"intervention":{"A":1},"reference":{"A":0}})
        pd.testing.assert_frame_equal(data,original)

    def test_categorical_action_or_outcome_abstains(self):
        for cat in ['A','Y']:
            graph={'nodes':[{'name':'A','family':'linear'if cat=='A'else'binary','variable_type':'categorical'if cat=='A'else'binary'},{'name':'Y','variable_type':'categorical'if cat=='Y'else'continuous'}],'edges':[['A','Y']]}
            e=Editor();ready=e.request('load_data',dict(graph,columns=['A','Y'],rows=[[i%2,i%3]for i in range(512)],mapping={'A':'A','Y':'Y'}))
            with patch('causalengine.editor_engine._reference',side_effect=AssertionError('No reference')):
                out=e.request('estimate_data',dict(graph,source='csv',data_id=ready['data_id'],targets=['Y'],intervention={'A':1},reference={'A':0},categorical_encoding='one_hot'))
            self.assertEqual(out['data_estimate']['status'],'UNSUPPORTED')
            self.assertNotIn('values',out['data_estimate'])

    def test_generic_observational_tree_has_no_q_or_extraction(self):
        case=next(c for c in graph_examples()if c['id']=='uca_napkin')
        result=analyze(dict(case,max_seconds=3,max_orders=0,max_mc_unions=0))
        self.assertEqual(result['identification']['status'],'IDENTIFIABLE')
        self.assertEqual(result['identification']['observational_formula_status'],'COMPLETE')
        tree=result['identification']['observational_formula_tree'];pending=[tree];types=set()
        while pending:
            item=pending.pop()
            if isinstance(item,dict):
                if 'type'in item:types.add(item['type'])
                pending.extend(item.values())
            elif isinstance(item,list):pending.extend(item)
        self.assertIn('ratio',types)
        self.assertNotIn('kernel',types)
        self.assertNotIn('extract',types)
        G=_graph(case);H,X,Y=graph_module.preprocess_query(G,case['X'],case['Y']);trace=identify.ID_return_Ctree(G,case['X'],case['Y'])
        with self.assertRaises(ii.ExpressionLimit):_observational_trace_tree(H,X,Y,trace,limit=1)
        self.assertEqual(result['identification']['status'],'IDENTIFIABLE')

if __name__=='__main__':unittest.main()
