"""Exact user constraints, actual XGBoost, training isolation and score routing."""
import copy,json,unittest
from unittest.mock import patch
import numpy as np
from scipy.optimize import minimize
from causalengine.balancing_aipw import (_fit_minimum_variance_weights as fit_weights,
 fit_xgboost_mean,estimate_balancing_aipw,WEIGHT_FLOOR)
import causalengine.balancing_aipw as core

class MinimumVarianceXgboostTests(unittest.TestCase):
 def test_exact_objective_constraints_and_independent_small_qp(self):
  mu=np.array([-2.,-.4,.2,1.,2.5,3.,-.3,1.2]);sel=np.array([1,1,1,1,0,0,0,0],bool)
  w,h,d=fit_weights(mu,sel,np.array([-3.,0.,4.]),lambda:None)
  n=len(mu);g=mu[sel]
  eq=[{'type':'eq','fun':lambda v:v.sum()/n-1}, {'type':'eq','fun':lambda v:v@g/n-mu.mean()}]
  q=minimize(lambda v:np.dot(v,v)/n,w+0.01,method='SLSQP',constraints=eq,bounds=[(WEIGHT_FLOOR,None)]*len(w),options={'ftol':1e-12,'maxiter':200})
  self.assertTrue(q.success,q.message);np.testing.assert_allclose(w,q.x,atol=1e-6)
  self.assertAlmostEqual(w.sum()/n,1,places=11);self.assertAlmostEqual(w@g/n,mu.mean(),places=11)
  self.assertAlmostEqual(d['objective'],w@w/n,places=12);self.assertLessEqual(abs(d['training_standardized_mu_residual']),1e-8)
  target=d['training_mu_target'];scale=d['training_mu_scale']
  np.testing.assert_allclose(h,np.maximum(WEIGHT_FLOOR,d['dual_intercept']+d['dual_slope']*(np.array([-3.,0.,4.])-target)/scale))
  self.assertFalse(np.isclose(h.mean(),1.)) # heldout is not renormalized

 def test_constant_ties_endpoints_and_floor_adjusted_infeasibility(self):
  mu=np.ones(8)*7;sel=np.arange(8)<4
  w,h,d=fit_weights(mu,sel,np.array([7.,90.]),lambda:None)
  np.testing.assert_array_equal(w,np.ones(4)*2);np.testing.assert_array_equal(h,[2,2]);self.assertEqual(d['dual_slope'],0)
  # Cohort mean chosen so the floor-adjusted selected-arm target is the upper
  # extreme. The unique optimum puts all excess mass on its two tied rows.
  eps=WEIGHT_FLOOR;mu=np.array([0.,1.,1.,(4-3*eps)*1+eps*2-2.])
  sel=np.array([1,1,1,0],bool);w,_,d=fit_weights(mu,sel,mu,lambda:None)
  self.assertEqual(d['solution_case'],'extreme-tie boundary');self.assertAlmostEqual(w[0],eps)
  self.assertAlmostEqual(w.sum()/4,1,places=10);self.assertAlmostEqual(w@mu[sel]/4,mu.mean(),places=10)
  with self.assertRaisesRegex(ValueError,'WEIGHT_FEASIBILITY'):fit_weights(np.array([0.,0.,2.,2.]),np.array([1,1,0,0],bool),np.array([0.]),lambda:None)

 def test_heldout_predictions_and_labels_cannot_change_training_weights(self):
  rng=np.random.default_rng(7);g=rng.normal(size=200);sel=np.arange(200)%2==0
  a,_,d=fit_weights(g,sel,np.ones(10),lambda:None);b,_,e=fit_weights(g,sel,np.ones(10)*100,lambda:None)
  np.testing.assert_array_equal(a,b)
  for k in ('dual_intercept','dual_slope','objective','training_mu_target','training_mass_residual'):
   self.assertEqual(d[k],e[k])

 def test_real_xgboost_zero_features_and_training_only_base_score(self):
  x=np.empty((200,0));y=np.linspace(0,4,200);q=np.empty((8,0))
  pred,d=fit_xgboost_mean(x,y,q,seed=7,check=lambda:None)
  self.assertEqual(d['regression'],'XGBoost');self.assertEqual(d['version'],'2.1.4');self.assertTrue(d['constant_zero_feature'])
  self.assertEqual(d['fits'][0]['params']['base_score'],y.mean());self.assertEqual(d['fits'][0]['rounds'],64)
  np.testing.assert_allclose(pred,y.mean(),atol=1e-5)

 def test_three_manual_scores_actual_nuisances_and_original_rows(self):
  rng=np.random.default_rng(41);x=rng.normal(size=(1024,3));a=rng.binomial(1,.5,1024);y=2*a+x.sum(1)+rng.normal(size=1024);old=[v.copy()for v in (x,a,y)]
  seed=53;n=len(a);fold=np.empty(n,int);rng=np.random.default_rng(seed)
  for arm in (0,1):
   ids=np.flatnonzero(a==arm);fold[rng.permutation(ids)]=np.arange(len(ids))%2
  m=np.empty((n,2));w=np.empty((n,2))
  for heldout in (0,1):
   t=np.flatnonzero(fold!=heldout);v=np.flatnonzero(fold==heldout)
   for arm in (0,1):
    sel=a[t]==arm;s=(seed+104729*(heldout+1)+1009*(arm+1))%2**32
    means,_=fit_xgboost_mean(x[t][sel],y[t][sel],np.vstack([x[t],x[v]]),seed=s,check=lambda:None)
    m[v,arm]=means[len(t):,0];_,w[v,arm],_=fit_weights(means[:len(t),0],sel,m[v,arm],lambda:None)
  scores={'outcome_regression':m[:,1]-m[:,0],'ipw':(a==1)*w[:,1]*y-(a==0)*w[:,0]*y,
   'aipw':m[:,1]-m[:,0]+(a==1)*w[:,1]*(y-m[:,1])-(a==0)*w[:,0]*(y-m[:,0])}
  # IPW now has an independently tested propensity nuisance, not these mu weights.
  for method in ('aipw','outcome_regression'):
   r=estimate_balancing_aipw(x,a,y,seed=seed,estimator=method);self.assertEqual(r['status'],'OK',r)
   self.assertAlmostEqual(r['estimate'],scores[method].mean(),places=12)
   self.assertEqual(r['estimation_details']['nuisance']['fit_calls'],{'outcome':4,'weights':0 if method=='outcome_regression' else 4,'propensity':0})
  for z,original in zip((x,a,y),old):np.testing.assert_array_equal(z,original)

 def test_or_never_weights_and_explicit_failures_no_value(self):
  rng=np.random.default_rng(41);x=rng.normal(size=(512,2));a=rng.binomial(1,.5,512);y=2*a+x.sum(1)
  with patch('causalengine.balancing_aipw._fit_minimum_variance_weights',side_effect=AssertionError('no OR weight fit')):
   r=estimate_balancing_aipw(x,a,y,estimator='outcome_regression');self.assertEqual(r['status'],'OK')
  with patch('causalengine.balancing_aipw.fit_xgboost_mean',side_effect=ValueError('intentional XGB failure')):
   r=estimate_balancing_aipw(x,a,y);self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)
  for method in ('aipw','ipw','outcome_regression'):
   r=estimate_balancing_aipw(x,a,y,max_seconds=1e-10,estimator=method);self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)
   q=estimate_balancing_aipw(x,a,y,estimator=method,intervention=1,reference=1)
   self.assertEqual(q['estimate'],0);self.assertEqual(q['estimation_details']['nuisance']['fit_calls'],{'outcome':0,'weights':0,'propensity':0})
