"""Existing seeded linear/binary/NumPy-neural Random outcome generators."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import unittest

import numpy as np
import pandas as pd
from scipy.special import expit
from causalengine import Editor


def configuration(dimension, family):
    action = dict(name="A", observed=True, dimension=dimension, family="binary", variable_type="binary")
    if dimension > 1:
        action["members"] = [f"a{i + 1}" for i in range(dimension)]
    return dict(nodes=[dict(name="X", family="linear"), action,
                       dict(name="Y", family=family, variable_type="binary" if family == "binary" else "continuous")],
                edges=[["X", "A"], ["X", "Y"], ["A", "Y"]], model_seed=7, noise="normal",
                random_cluster_sizes={"X": 5}, random_cluster_members={"X": [f"x{i + 1}" for i in range(5)]})


class OutcomeModelTests(unittest.TestCase):
    cases = {}
    report = dict(settings=dict(model_seed=7, data_seed=5, n=512, X_dimension=5), cases={})

    @classmethod
    def setUpClass(cls):
        for dimension in (1, 2):
            for family in ("linear", "binary", "neural_network"):
                key = f"A{dimension}-{family}"
                graph = configuration(dimension, family)
                editor = Editor()
                built = editor.request("build", copy.deepcopy(graph))
                before = copy.deepcopy(editor.model.describe())
                sample = editor.request("sample", dict(token=built["token"], random_key=built["random_key"], n=512, data_seed=5))
                frame = pd.read_csv(io.StringIO(sample["csv"]))
                cls.cases[key] = editor, graph, built, sample, frame, before
                cls.report["cases"][key] = dict(columns=sample["columns"], shape=sample["shape"], model=built["model"],
                    csv_sha256=hashlib.sha256(sample["csv"].encode()).hexdigest(), Y_min=float(frame.Y.min()), Y_max=float(frame.Y.max()),
                    Y_unique=int(frame.Y.nunique()), family=family)

    @classmethod
    def tearDownClass(cls):
        if os.environ.get("OUTCOME_MODEL_REPORT"):
            Path(os.environ["OUTCOME_MODEL_REPORT"]).write_text(json.dumps(cls.report, indent=2) + "\n")

    def test_generation_domain_metadata_and_seed_replay(self):
        for key, (editor, graph, built, sample, frame, before) in self.cases.items():
            dimension = graph["nodes"][1]["dimension"]
            family = graph["nodes"][2]["family"]
            members = ["A"] if dimension == 1 else ["a1", "a2"]
            with self.subTest(case=key):
                self.assertEqual(sample["columns"], [*[f"x{i + 1}" for i in range(5)], *members, "Y"])
                self.assertEqual(sample["shape"], [512, 6 + dimension])
                self.assertTrue(np.isfinite(frame.Y.to_numpy()).all())
                self.assertTrue(np.isin(frame[members].to_numpy(), [0, 1]).all())
                variable = built["model"]["variables"]["Y"]
                self.assertEqual(variable["parameters"]["family"], family)
                self.assertEqual(variable["variable_type"], "binary" if family == "binary" else "continuous")
                if family == "binary":
                    self.assertEqual(set(frame.Y.unique()), {0, 1})
                else:
                    self.assertGreater(frame.Y.nunique(), 2)
                fresh = Editor()
                rebuilt = fresh.request("build", copy.deepcopy(graph))
                regenerated = fresh.request("sample", dict(token=rebuilt["token"], random_key=rebuilt["random_key"], n=512, data_seed=5))
                self.assertEqual(regenerated["csv"], sample["csv"])
                self.assertEqual(rebuilt["model"], built["model"])
                self.assertEqual(editor.model.describe(), before)

    def test_binary_threshold_and_neural_independent_forward(self):
        for key, (editor, graph, built, sample, frame, before) in self.cases.items():
            family = graph["nodes"][2]["family"]
            if family == "linear":
                continue
            with self.subTest(case=key):
                params = built["model"]["variables"]["Y"]["equation"]["parameters"]
                parameters = params.get("coordinates", [params])[0]
                self.assertEqual(parameters["kind"], family)
                inputs = {}
                for parent in editor.model.graph.predecessors("Y"):
                    details = editor.model._variables[parent]
                    for i, column in enumerate(details["columns"]):
                        inputs[f"{parent}[{i}]" if details["shape"] else parent] = frame[column].to_numpy()
                rng = editor.model._variable_rng(5, "Y")
                noise = editor.model._draw_noise("Y", rng, 512)
                if family == "binary":
                    score = np.full(512, parameters["intercept"])
                    for name, coefficient in parameters["coefficients"].items():
                        score += coefficient * inputs[name]
                    expected = (rng.random(512) < expit(score + noise)).astype(int)
                    np.testing.assert_array_equal(frame.Y.to_numpy(), expected)
                else:
                    hidden = np.column_stack([inputs[name] for name in parameters["parents"]])
                    weights = [parameters["input_weights"], *parameters["hidden_weights"]]
                    biases = [parameters["bias"], *parameters["hidden_biases"]]
                    self.assertEqual(len(weights), parameters["depth"])
                    for weight, bias in zip(weights, biases):
                        hidden = hidden @ np.asarray(weight) + np.asarray(bias)
                        hidden = np.tanh(hidden) if parameters["activation"] == "tanh" else np.maximum(hidden, 0)
                    expected = hidden @ np.asarray(parameters["output_weights"]) + parameters["intercept"] + noise
                    np.testing.assert_allclose(frame.Y.to_numpy(), expected, atol=1e-12, rtol=1e-12)
                self.report["cases"][key]["independent_forward_max_error"] = float(np.max(np.abs(frame.Y.to_numpy() - expected)))

    def test_three_outcomes_cluster_apo_ipw_reference_and_snapshot(self):
        for family in ("linear", "binary", "neural_network"):
            key = "A2-" + family
            editor, graph, built, sample, frame, before = self.cases[key]
            with self.subTest(family=family):
                query = dict(copy.deepcopy(graph), source="random", token=built["token"], sample_id=sample["sample_id"],
                    random_key=built["random_key"], type="interventional", targets=["Y"], intervention={"A": [1, 1]},
                    estimand="apo", summary="mean", estimation_method="ipw", n=256, max_seconds=10)
                data_before = editor._sample.copy(deep=True)
                result = editor.request("estimate_data", query)["data_estimate"]
                self.assertEqual(result["status"], "OK", result)
                self.assertTrue(np.isfinite(result["values"]["Y"]))
                details = result["estimation_details"]
                self.assertEqual(details["inputs"]["treatment_members"], ["a1", "a2"])
                self.assertEqual(details["inputs"]["intervention"], [1, 1])
                self.assertIsNone(details["inputs"]["reference"])
                self.assertEqual(details["nuisance"]["fit_calls"], dict(outcome=0, weights=0, propensity=2))
                answer = editor.request("sample_reference", query)
                reference = answer["model_reference"]
                self.assertEqual(reference["status"], "OK", reference)
                self.assertIsNone(reference["query"]["reference"])
                self.assertTrue(reference["approximate"])
                self.assertTrue(np.isfinite(reference["values"]["Y"]))
                world = editor.model.sample_interventional(query["intervention"], 256, seed=answer["reference_seed"])["Y"].to_numpy()
                self.assertAlmostEqual(reference["values"]["Y"], float(world.mean()), places=12)
                if family == "binary":
                    self.assertGreaterEqual(reference["values"]["Y"], 0)
                    self.assertLessEqual(reference["values"]["Y"], 1)
                self.assertTrue(editor._sample.equals(data_before))
                self.assertEqual(editor.model.describe(), before)
                self.report["cases"][key].update(estimate=result, model_reference=answer)
