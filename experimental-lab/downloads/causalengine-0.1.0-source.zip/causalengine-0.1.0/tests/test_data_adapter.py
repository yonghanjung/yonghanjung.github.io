"""Data-only API tests: uploaded rows, independent identification and version guards."""
import copy
import unittest
from unittest.mock import patch
from causalengine import Editor, analyze

GRAPH = {"nodes": [{"name":"A", "family":"binary"}, {"name":"Y", "family":"linear"}], "edges":[["A","Y"]]}
QUERY = {"type":"interventional", "summary":"mean_difference", "targets":["Y"], "intervention":{"A":1}, "reference":{"A":0}, "Z":[], "max_seconds":5}

def upload(effect=3):
    return dict(copy.deepcopy(GRAPH), columns=["assignment", "score"], mapping={"A":"assignment", "Y":"score"},
                rows=[[i % 2, 10 + effect * (i % 2)] for i in range(512)])

class DataOnlyTests(unittest.TestCase):
    def test_upload_controls_result_without_any_scm_or_reference(self):
        editor=Editor()
        with patch("causalengine.editor_engine.build_scm", side_effect=AssertionError("SCM must not be built")), patch("causalengine.editor_engine._reference", side_effect=AssertionError("No reference allowed")):
            for effect in (3, -7):
                ready=editor.request("load_data", upload(effect))
                answer=editor.request("estimate_data", dict(GRAPH, **QUERY, source="csv", data_id=ready["data_id"]))
                self.assertEqual(answer["data_estimate"]["status"], "OK")
                self.assertAlmostEqual(answer["data_estimate"]["values"]["Y"], effect)
                self.assertNotIn("scm_reference", answer)
                self.assertNotIn("difference", answer)
                self.assertIsNone(editor.model)

    def test_identify_needs_no_dataset_or_editor_model(self):
        with patch("causalengine.editor_engine.build_scm", side_effect=AssertionError("No model")):
            answer=analyze(dict(GRAPH, X=["A"], Y=["Y"], Z=[], max_seconds=3))
        self.assertEqual(answer["identification"]["status"], "IDENTIFIABLE")

    def test_csv_stale_id_graph_types_and_failed_reload(self):
        editor=Editor()
        first=editor.request("load_data", upload())
        second=editor.request("load_data", upload())
        with self.assertRaisesRegex(ValueError, "expired"):
            editor.request("estimate_data", dict(GRAPH, **QUERY, source="csv", data_id=first["data_id"]))
        changed=copy.deepcopy(GRAPH); changed["edges"]=[]
        with self.assertRaisesRegex(ValueError, "graph"):
            editor.request("estimate_data", dict(changed, **QUERY, source="csv", data_id=second["data_id"]))
        changed=copy.deepcopy(GRAPH); changed["nodes"][0]["family"]="linear"
        with self.assertRaisesRegex(ValueError, "types"):
            editor.request("estimate_data", dict(changed, **QUERY, source="csv", data_id=second["data_id"]))
        bad=upload(); bad["rows"][0][1]=None
        with self.assertRaises(ValueError): editor.request("load_data",bad)
        with self.assertRaisesRegex(ValueError, "expired"):
            editor.request("estimate_data", dict(GRAPH, **QUERY, source="csv", data_id=second["data_id"]))

    def test_invalid_csv_inputs_fail_without_dropping_rows(self):
        cases=[]
        for value in (None, "3", True, float("nan"), float("inf")):
            bad=upload();bad["rows"][9][1]=value;cases.append(bad)
        for headers in (["assignment","assignment"],["assignment",""]):
            bad=upload();bad["columns"]=headers;cases.append(bad)
        bad=upload();bad["mapping"]["Y"]="assignment";cases.append(bad)
        bad=upload();bad["mapping"].pop("Y");cases.append(bad)
        bad=upload();bad["rows"]=[];cases.append(bad)
        bad=upload();bad["rows"][0]=[0];cases.append(bad)
        bad=upload();bad["rows"][0][0]=2;cases.append(bad)
        bad=upload();bad["nodes"][0]["dimension"]=2;cases.append(bad)
        bad=upload();bad["nodes"][0]["variable_type"]="continuous";cases.append(bad)
        for i,bad in enumerate(cases):
            with self.subTest(case=i), self.assertRaises(ValueError): Editor().request("load_data",bad)

    def test_random_estimation_uses_sample_and_no_reference(self):
        editor=Editor(); built=editor.request("build",dict(GRAPH,model_seed=7,noise="normal"))
        sampled=editor.request("sample",dict(token=built["token"],n=512,data_seed=5))
        payload=dict(GRAPH, **QUERY,source="random",token=built["token"],sample_id=sampled["sample_id"])
        with patch("causalengine.editor_engine._reference",side_effect=AssertionError("No reference allowed")):
            result=editor.request("estimate_data",payload)
        self.assertEqual(result["data_estimate"]["status"],"OK")
        self.assertNotIn("scm_reference",result)
        with self.assertRaisesRegex(ValueError,"sample expired"):
            editor.request("estimate_data",dict(payload,sample_id=sampled["sample_id"]+1))
        with self.assertRaisesRegex(ValueError,"model expired"):
            editor.request("estimate_data",dict(payload,token=built["token"]+1))
        changed=copy.deepcopy(payload);changed["edges"]=[]
        with self.assertRaisesRegex(ValueError,"graph changed"):
            editor.request("estimate_data",changed)

    def test_nonancestor_empty_action_contrast_is_zero_from_same_data(self):
        editor=Editor(); graph=copy.deepcopy(GRAPH); graph["edges"]=[]
        ready=editor.request("load_data",dict(upload(), **graph))
        with patch("causalengine.editor_engine._reference",side_effect=AssertionError("No model reference")):
            result=editor.request("estimate_data",dict(graph,**dict(QUERY,intervention={},reference={}),source="csv",data_id=ready["data_id"]))
        self.assertEqual(result["data_estimate"]["status"],"OK")
        self.assertEqual(result["data_estimate"]["values"]["Y"],0)
        self.assertEqual(result["data_id"],ready["data_id"])

    def test_unsupported_query_abstains_and_binary_action_is_checked(self):
        editor=Editor();ready=editor.request("load_data",upload())
        payload=dict(GRAPH,**QUERY,source="csv",data_id=ready["data_id"])
        result=editor.request("estimate_data",dict(payload,type="counterfactual"))
        self.assertEqual(result["data_estimate"]["status"],"UNSUPPORTED")
        self.assertNotIn("values",result["data_estimate"])
        with self.assertRaisesRegex(ValueError,"binary action"):
            editor.request("estimate_data",dict(payload,intervention={"A":2}))

if __name__=="__main__":unittest.main()
