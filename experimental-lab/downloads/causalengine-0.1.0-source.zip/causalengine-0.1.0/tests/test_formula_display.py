"""Numerical regression of display-only generic ID expansion, not a proof."""
import copy
from functools import lru_cache
from itertools import product
import unittest
import networkx as nx
import numpy as np
from causalengine import analyze,graph_examples


def positive_binary_world(case,seed):
    graph=nx.DiGraph();graph.add_nodes_from(n['name']for n in case['nodes']);graph.add_edges_from(case['edges'])
    order=list(nx.topological_sort(graph));parents={v:sorted(graph.predecessors(v))for v in order}
    rng=np.random.default_rng(seed)
    tables={v:{bits:float(rng.uniform(.15,.85))for bits in product((0,1),repeat=len(parents[v]))}for v in order}
    observed=[n['name']for n in case['nodes']if n.get('observed',True)]
    def distribution(actions):
        answer={bits:0. for bits in product((0,1),repeat=len(observed))}
        for bits in product((0,1),repeat=len(order)):
            state=dict(zip(order,bits));weight=1.
            for v in order:
                if v in actions:
                    if state[v]!=actions[v]:weight=0.;break
                else:
                    p=tables[v][tuple(state[p]for p in parents[v])];weight*=p if state[v]else 1-p
            answer[tuple(state[v]for v in observed)]+=weight
        return answer
    joint=distribution({})
    @lru_cache(None)
    def marginal(items):
        constraints=dict(items)
        return sum(weight for bits,weight in joint.items()if all(dict(zip(observed,bits))[v]==value for v,value in constraints.items()))
    def probability(outcomes,given):
        merged=dict(given)
        if any(v in merged and merged[v]!=a for v,a in outcomes.items()):return 0.
        merged.update(outcomes)
        return marginal(tuple(sorted(merged.items())))/marginal(tuple(sorted(given.items())))
    def evaluate(tree,env):
        kind=tree['type']
        if kind=='number':return float(tree['value'])
        if kind=='probability':
            def args(items):return {a['variable']:a['value']if'value'in a else env[a.get('label',a['variable'])]for a in items}
            return probability(args(tree['outcomes']),args(tree['given']))
        if kind=='product':return float(np.prod([evaluate(f,env)for f in tree['factors']]))
        if kind=='ratio':return evaluate(tree['numerator'],env)/evaluate(tree['denominator'],env)
        if kind=='sum':
            return sum(evaluate(tree['body'],dict(env,**{a.get('label',a['variable']):value for a,value in zip(tree['variables'],bits)}))for bits in product((0,1),repeat=len(tree['variables'])))
        if kind=='add':return evaluate(tree['left'],env)+evaluate(tree['right'],env)
        raise AssertionError('Unexpanded display node: '+kind)
    return observed,distribution,evaluate

class GenericFormulaRegression(unittest.TestCase):
    def test_closed_generic_tree_matches_positive_binary_interventions(self):
        cases={c['id']:c for c in graph_examples()}
        selected=[copy.deepcopy(cases[k])for k in ['uca_napkin','uca_beyond_tian','uca_sbd']]
        correlated=copy.deepcopy(cases['uca_napkin']);correlated['id']='napkin_correlated_contexts';correlated['nodes'].append({'name':'E','observed':True});correlated['edges'] += [['C','E'],['E','R']];selected.append(correlated)
        for index,case in enumerate(selected):
            with self.subTest(case=case['id']):
                result=analyze(dict(case,max_seconds=5,max_orders=0,max_mc_unions=0))
                self.assertEqual(result['identification']['status'],'IDENTIFIABLE')
                self.assertEqual(result['identification']['observational_formula_status'],'COMPLETE')
                contexts=result['identification']['observational_formula_contexts']
                if case['id']=='napkin_correlated_contexts':self.assertTrue({'E','R'}<=set(contexts))
                observed,distribution,evaluate=positive_binary_world(case,100+index)
                target=case['Y'][0];tree=result['identification']['observational_formula_tree']
                for setting in (0,1):
                    actions={v:setting for v in case['X']};truth=distribution(actions)
                    expected=sum(bits[observed.index(target)]*weight for bits,weight in truth.items())
                    p0=evaluate(tree,dict(actions,**{target:0}));p1=evaluate(tree,dict(actions,**{target:1}))
                    self.assertAlmostEqual(p0+p1,1.,places=10)
                    self.assertAlmostEqual(p1,expected,places=10)

if __name__=='__main__':unittest.main()
