"""Joint-treatment propensity IPW, actual estimand semantics and snapshot guards."""
import copy,hashlib,importlib.util,json,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from causalengine import Editor
import causalengine.balancing_aipw as core

G={'nodes':[{'name':'X'},{'name':'A','family':'binary','dimension':2,'members':['a1','a2']},{'name':'Y'}],'edges':[['X','A'],['X','Y'],['A','Y']]}
class PropensityApoClusterTests(unittest.TestCase):
 def test_correlated_joint_probability_not_product_manual_ate_apo(self):
  a=np.repeat([[0,0],[0,1],[1,0],[1,1]],[90,10,10,90],axis=0);y=np.repeat([2.,5.,7.,11.],[90,10,10,90]);x=np.zeros((200,1))
  def classifier(train,labels,query,**kw):return np.tile([.45,.05,.05,.45],(len(query),1)),dict(params={'objective':'multi:softprob','num_class':4},class_counts=np.bincount(labels).tolist())
  with patch.object(core,'fit_xgboost_propensity',side_effect=classifier),patch.object(core,'fit_xgboost_mean',side_effect=AssertionError('IPW must never fit Y')):
   apo=core.estimate_balancing_aipw(x,a,y,intervention=[1,1],estimand='apo',estimator='ipw')
   ate=core.estimate_balancing_aipw(x,a,y,intervention=[1,1],reference=[0,0],estimator='ipw')
  self.assertEqual(apo['status'],'OK',apo);self.assertAlmostEqual(apo['estimate'],11,places=12);self.assertAlmostEqual(ate['estimate'],9,places=12)
  self.assertEqual(apo['estimation_details']['nuisance']['fit_calls'],{'outcome':0,'weights':0,'propensity':2})
  self.assertTrue(apo['estimation_details']['nuisance']['used']['weights']);self.assertFalse(apo['estimation_details']['nuisance']['fitted']['weights'])

 def test_actual_joint_classifier_no_outcome_learning_and_query_identities(self):
  rng=np.random.default_rng(22);x=rng.normal(size=(1200,2));a=rng.binomial(1,.5,(1200,2));y=a[:,0]+2*a[:,1]+x.sum(1)+rng.normal(size=1200)
  with patch.object(core,'fit_xgboost_mean',side_effect=AssertionError('No outcome fit')):
   ate=core.estimate_balancing_aipw(x,a,y,intervention=[1,1],reference=[0,0],estimator='ipw')
   apo=core.estimate_balancing_aipw(x,a,y,intervention=[1,1],estimand='apo',estimator='ipw')
   ref=core.estimate_balancing_aipw(x,a,y,intervention=[0,0],estimand='apo',estimator='ipw')
   changed=core.estimate_balancing_aipw(x,a,y[::-1],intervention=[1,1],reference=[0,0],estimator='ipw')
  self.assertEqual(ate['status'],'OK',ate);self.assertAlmostEqual(ate['estimate'],apo['estimate']-ref['estimate'],places=12)
  self.assertEqual(ate['diagnostics']['fold_details'],changed['diagnostics']['fold_details'])
  for f in ate['diagnostics']['fold_details']:self.assertEqual(f['propensity_fit']['params']['objective'],'multi:softprob')

 def test_apo_no_reference_support_and_ate_identical_zero_without_fit(self):
  rng=np.random.default_rng(33);x=np.empty((512,0));a=np.r_[np.zeros(12),np.ones(500)];y=3+a
  for method in ('aipw','outcome_regression','ipw'):
   r=core.estimate_balancing_aipw(x,a,y,intervention=1,estimand='apo',estimator=method)
   self.assertEqual(r['status'],'OK',r)
   equal=core.estimate_balancing_aipw(x,a,y,intervention=1,reference=1,estimator=method);self.assertEqual(equal['estimate'],0)
   self.assertEqual(equal['estimation_details']['nuisance']['fit_calls'],{'outcome':0,'weights':0,'propensity':0})
  with self.assertRaisesRegex(ValueError,'no reference'):core.estimate_balancing_aipw(x,a,y,estimand='apo',reference=0)

 def test_absent_joint_regime_continuous_component_and_small_probability_fail(self):
  a=np.tile([[0,0],[1,1]],(256,1));x=np.zeros((512,1));y=np.arange(512,dtype=float)
  r=core.estimate_balancing_aipw(x,a,y,intervention=[1,0],reference=[0,0],estimator='ipw');self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)
  def bad(train,labels,query,**kw):return np.tile([1-1e-8,1e-8],(len(query),1)),dict(params={'objective':'binary:logistic'})
  with patch.object(core,'fit_xgboost_propensity',side_effect=bad):
   r=core.estimate_balancing_aipw(x,a,y,intervention=[1,1],estimand='apo',estimator='ipw')
  self.assertEqual(r['status'],'UNKNOWN');self.assertTrue(r['reason'].startswith('PROPENSITY_SUPPORT'));self.assertNotIn('estimate',r)
  with self.assertRaisesRegex(ValueError,'binary'):core.estimate_balancing_aipw(x,a+.1,y,intervention=[1,1],estimator='ipw')

 def test_csv_tuple_and_real_generated_tuple_aliases_snapshots_apo_reference(self):
  rng=np.random.default_rng(22);x=rng.normal(size=1200);a=rng.binomial(1,.5,(1200,2));y=a[:,0]+2*a[:,1]+x+rng.normal(size=1200)
  e=Editor();mapping={'X':'x','A':['first','second'],'Y':'out'}
  ready=e.request('load_data',dict(G,columns=['x','first','second','out'],rows=np.column_stack([x,a,y]).tolist(),mapping=mapping,column_types={'first':'binary','second':'binary'}))
  q=dict(G,source='csv',data_id=ready['data_id'],binding_key=ready['binding_key'],type='interventional',summary='mean',estimand='apo',targets=['Y'],intervention={'A':[1,1]},estimation_method='ipw')
  r=e.request('estimate_data',q);self.assertEqual(r['data_estimate']['status'],'OK',r)
  self.assertEqual(r['data_estimate']['estimation_details']['inputs']['treatment'],['first','second'])
  with self.assertRaisesRegex(ValueError,'no reference'):e.request('estimate_data',dict(q,reference={'A':[0,0]}))
  b=e.request('build',dict(G,model_seed=7,noise='normal'));s=e.request('sample',dict(token=b['token'],n=1200,data_seed=5))
  self.assertIn('a1',s['columns']);self.assertIn('a2',s['columns']);self.assertTrue(np.isin(np.array(s['rows'])[:,[1,2]],[0,1]).all())
  rq=dict(G,source='random',token=b['token'],sample_id=s['sample_id'],type='interventional',summary='mean',estimand='apo',targets=['Y'],intervention={'A':[1,1]},estimation_method='ipw',n=256,max_seconds=10)
  estimate=e.request('estimate_data',rq);self.assertEqual(estimate['data_estimate']['status'],'OK',estimate)
  ref=e.request('sample_reference',rq);self.assertEqual(ref['model_reference']['status'],'OK',ref);self.assertEqual(ref['model_reference']['query']['summary'],'mean');self.assertNotIn('reference_values',ref['model_reference'])
  changed=copy.deepcopy(rq);changed['nodes'][1]['members']=['a2','a1']
  with self.assertRaisesRegex(ValueError,'graph'):e.request('estimate_data',changed)
