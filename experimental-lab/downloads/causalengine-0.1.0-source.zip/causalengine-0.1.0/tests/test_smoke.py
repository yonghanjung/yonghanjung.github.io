import hashlib
import json
from pathlib import Path
import unittest

from causalengine import Editor, analyze
from causalengine.demo import run_demo

class EngineSmokeTests(unittest.TestCase):
    def test_binary_simulation_and_estimate(self):
        result = run_demo()
        self.assertEqual(result["rows"], 512)
        self.assertNotIn("U", result["columns"])
        a = result["columns"].index("A")
        self.assertTrue(all(row[a] in (0, 1) for row in result["preview"]))
        comparison = result["comparison"]
        self.assertEqual(comparison["scm_reference"]["status"], "OK")
        self.assertFalse(comparison["scm_reference"]["approximate"])
        self.assertEqual(comparison["data_estimate"]["status"], "OK")
        self.assertAlmostEqual(comparison["difference"]["Y"], comparison["data_estimate"]["values"]["Y"] - comparison["scm_reference"]["values"]["Y"])

    def test_identification_simple_observed_graph(self):
        answer = analyze({"nodes": [{"name":"A", "observed": True}, {"name":"Y", "observed":True}], "edges":[["A","Y"]], "X":["A"], "Y":["Y"], "Z":[], "max_seconds":3})
        self.assertEqual(answer["identification"]["status"], "IDENTIFIABLE")

    def test_invalid_graph_rejected(self):
        with self.assertRaises(ValueError):
            Editor().request("build", {"nodes":[{"name":"A", "observed":True}, {"name":"Y", "observed":True}], "edges":[["A","Y"],["Y","A"]], "model_seed":7, "noise":"normal"})

    def test_preserved_upstream_hashes(self):
        root=Path(__file__).resolve().parents[1]
        manifest=json.loads((root/"PROVENANCE.json").read_text())
        for item in manifest["files"]:
            self.assertEqual(hashlib.sha256((root/"upstream"/item["path"]).read_bytes()).hexdigest(), item["sha256"])

if __name__ == "__main__":
    unittest.main()
