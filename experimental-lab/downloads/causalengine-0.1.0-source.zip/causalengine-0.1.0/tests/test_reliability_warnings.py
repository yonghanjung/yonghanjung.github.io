"""Reliability diagnostics never replace an actually finite selected score."""
import time,unittest
from unittest.mock import patch
import numpy as np
from causalengine import Editor
import causalengine.balancing_aipw as core
import causalengine.editor_engine as engine

G={'nodes':[{'name':'X'},{'name':'A','family':'binary'},{'name':'Y'}],'edges':[['X','A'],['X','Y'],['A','Y']]}
def codes(result):return {w['code']for w in result['warnings']}

class ReliabilityWarningTests(unittest.TestCase):
 def test_small_total_and_arm_counts_compute_all_three_scores(self):
  a=np.tile([0.,1.],8);x=np.zeros((16,1));y=1+2*a
  for method in ('aipw','outcome_regression','ipw'):
   r=core.estimate_balancing_aipw(x,a,y,estimator=method)
   self.assertEqual(r['status'],'OK',r);self.assertAlmostEqual(r['estimate'],2,places=10)
   self.assertIn('SMALL_SAMPLE',codes(r));self.assertIn('SMALL_TRAINING_ARM',codes(r))
   self.assertTrue(all(w['reference_threshold']==32 for w in r['warnings']if w['code']=='SMALL_TRAINING_ARM'))
   if method!='outcome_regression':self.assertIn('SMALL_HELDOUT_ARM',codes(r))

 def test_positive_tiny_propensity_and_concentration_warn_without_clipping(self):
  n=64;x=np.arange(n,dtype=float)[:,None];a=np.arange(n)%2;y=np.ones(n);captured=[]
  def fit(train,labels,query,**kw):
   p=np.full(len(query),.5);p[np.flatnonzero(query[:,0]%2==1)[0]]=1e-12
   captured.append((query[:,0].astype(int),p));return np.column_stack([1-p,p]),dict(params={'objective':'binary:logistic'})
  with patch.object(core,'fit_xgboost_propensity',side_effect=fit),patch.object(core,'fit_xgboost_mean',side_effect=AssertionError('IPW never fits outcomes')):
   r=core.estimate_balancing_aipw(x,a,y,intervention=1,estimand='apo',estimator='ipw')
  self.assertEqual(r['status'],'OK',r);self.assertTrue({'LOW_PROPENSITY','LOW_EFFECTIVE_SAMPLE_SIZE','CONCENTRATED_WEIGHTS'}<=codes(r))
  raw=np.zeros(n)
  for ids,p in captured:raw[ids]=(a[ids]==1)/p
  self.assertEqual(r['estimate'],float(raw.mean()));self.assertFalse(r['estimation_details']['options']['probability_clipping'])
  def zero(train,labels,query,**kw):return np.tile([1.,0.],(len(query),1)),{}
  with patch.object(core,'fit_xgboost_propensity',side_effect=zero):bad=core.estimate_balancing_aipw(x,a,y,intervention=1,estimand='apo',estimator='ipw')
  self.assertEqual(bad['reason_code'],'INVALID_PROPENSITY');self.assertNotIn('estimate',bad)

 def test_real_missing_training_failures_are_estimator_specific(self):
  x=np.zeros((32,1));a=np.r_[0.,np.ones(31)];y=1+2*a
  with patch.object(core,'fit_xgboost_propensity',side_effect=AssertionError('OR has no propensity requirement')):
   r=core.estimate_balancing_aipw(x,a,y,intervention=1,estimand='apo',estimator='outcome_regression')
  self.assertEqual(r['status'],'OK',r)
  missing=core.estimate_balancing_aipw(x,np.ones(32),y,intervention=0,estimand='apo',estimator='outcome_regression')
  self.assertEqual(missing['reason_code'],'MISSING_ASSIGNMENT');self.assertNotIn('estimate',missing)
  empty=core.estimate_balancing_aipw(np.zeros((1,1)),np.ones(1),np.ones(1),intervention=1,estimand='apo',estimator='outcome_regression')
  self.assertEqual(empty['reason_code'],'EMPTY_TRAINING_FOLD');self.assertNotIn('estimate',empty)
  with patch.object(core,'fit_xgboost_mean',side_effect=ValueError('intentional actual fit failure')):
   failed=core.estimate_balancing_aipw(x,a,y,intervention=1,estimand='apo',estimator='outcome_regression')
  self.assertEqual(failed['status'],'UNKNOWN');self.assertIn('intentional actual fit failure',failed['reason']);self.assertNotIn('estimate',failed)

 def test_all_selected_minimum_variance_solution_is_uniform_one(self):
  mu=np.array([1.,2.,4.,5.]);w,heldout,d=core._fit_minimum_variance_weights(mu,np.ones(4,bool),np.array([-3.,8.]),lambda:None)
  np.testing.assert_allclose(w,1,atol=1e-12);np.testing.assert_allclose(heldout,1,atol=1e-12)
  self.assertAlmostEqual(w.sum()/len(mu),1,places=12);self.assertAlmostEqual(w@mu/len(mu),mu.mean(),places=12)
  self.assertTrue(d['solver_success'])

 def test_legacy_small_sources_disclose_requested_and_available_k(self):
  e=Editor();x=np.arange(16,dtype=float);a=np.arange(16)%2;y=2*a+.5*x
  ready=e.request('load_data',dict(G,columns=['X','A','Y'],rows=np.column_stack([x,a,y]).tolist(),mapping={n:n for n in ('X','A','Y')}))
  r=e.request('estimate_data',dict(G,source='csv',data_id=ready['data_id'],type='interventional',summary='mean',estimand='apo',targets=['Y'],intervention={'A':1},estimation_method='legacy_knn'))['data_estimate']
  self.assertEqual(r['status'],'OK',r);self.assertIn('SMALL_TRAINING_SOURCE',codes(r))
  pools=r['diagnostics']['neighbor_pools'];self.assertTrue(any(p['actual_k']<p['requested_k']for p in pools))
  self.assertTrue(all(p['actual_k']<=p['source_rows']for p in pools))

 def test_uca_small_sources_use_available_pool_with_explicit_warning(self):
  g={'nodes':[{'name':'U','observed':False},{'name':'A','family':'binary'},{'name':'M','family':'binary'},{'name':'Y'}],'edges':[['U','A'],['U','Y'],['A','M'],['M','Y']]}
  rows=[[a,m,float(a+2*m)]for a in(0,1)for m in(0,1)for _ in range(8)];e=Editor()
  ready=e.request('load_data',dict(g,columns=['A','M','Y'],rows=rows,mapping={n:n for n in ('A','M','Y')}))
  r=e.request('estimate_data',dict(g,source='csv',data_id=ready['data_id'],type='interventional',summary='mean',estimand='apo',targets=['Y'],intervention={'A':1},estimation_method='legacy_knn'))['data_estimate']
  self.assertEqual(r['status'],'OK',r);self.assertIn('SMALL_KERNEL_SOURCE',codes(r))
  self.assertTrue(all('requested_k'in k and 'actual_k'in k for k in r['diagnostics']['kernels']))
