"""General graph regression routing; nonterminal kernels remain sampling kernels."""
import unittest,copy,time
from unittest.mock import patch
import numpy as np,pandas as pd
from causalengine import Editor
import causalengine.editor_engine as engine
from causalengine.balancing_aipw import fit_xgboost_mean as actual_fit

class RegressionRoutingTests(unittest.TestCase):
 def test_adjustment_mean_calls_actual_xgboost_including_constant_context(self):
  G={'nodes':[{'name':'X'},{'name':'A','family':'binary'},{'name':'Y'}], 'edges':[['X','A'],['X','Y'],['A','Y']]}
  for constant in (False,True):
   rng=np.random.default_rng(41);x=np.zeros(512) if constant else rng.normal(size=512);a=rng.binomial(1,.5,512);y=2*a+x+rng.normal(size=512)
   e=Editor();ready=e.request('load_data',dict(G,columns=['X','A','Y'],rows=np.column_stack([x,a,y]).tolist(),mapping={k:k for k in ('X','A','Y')}))
   with patch('causalengine.balancing_aipw.fit_xgboost_mean',wraps=actual_fit)as fit:
    r=e.request('estimate_data',dict(G,source='csv',data_id=ready['data_id'],type='interventional',summary='mean_difference',targets=['Y'],intervention={'A':1},reference={'A':0},estimation_method='legacy_knn',max_seconds=10))['data_estimate']
   self.assertEqual(r['status'],'OK',r);self.assertEqual(fit.call_count,4)
   self.assertTrue(all('XGBoost' in arm['method']for arm in r['diagnostics']['arms'].values()))

 def test_frontdoor_terminal_means_are_xgboost_but_sampling_kernels_remain(self):
  G={'nodes':[{'name':'U','observed':False},{'name':'A','family':'binary'},{'name':'M'},{'name':'Y'}], 'edges':[['U','A'],['U','Y'],['A','M'],['M','Y']]}
  e=Editor();b=e.request('build',dict(G,model_seed=7));s=e.request('sample',dict(token=b['token'],n=512,data_seed=5))
  with patch('causalengine.balancing_aipw.fit_xgboost_mean',wraps=actual_fit)as fit:
   r=e.request('estimate_data',dict(G,source='random',token=b['token'],sample_id=s['sample_id'],type='interventional',summary='mean_difference',targets=['Y'],intervention={'A':1},reference={'A':0},max_seconds=10))['data_estimate']
  self.assertEqual(r['status'],'OK',r);self.assertGreater(fit.call_count,0)
  kernels=[k for arm in r['diagnostics']['arms'].values()for k in arm['diagnostics'].get('kernels',[])]
  self.assertTrue(any(k['terminal_mean']and k.get('regressions')for k in kernels))
  self.assertTrue(any(not k['terminal_mean'] for k in kernels))

 def test_no_action_empirical_mean_is_not_falsely_called_regression(self):
  G={'nodes':[{'name':'A','family':'binary'},{'name':'Y'}],'edges':[['A','Y']]};e=Editor()
  r=e.request('load_data',dict(G,columns=['A','Y'],rows=[[i%2,float(i)]for i in range(512)],mapping={'A':'A','Y':'Y'}))
  with patch('causalengine.balancing_aipw.fit_xgboost_mean',side_effect=AssertionError('unconditional mean needs no fit')):
   state=e._uploaded
   out=engine._estimate_mean(state['data'],state['graph'],state['schema'],dict(type='interventional',summary='mean',targets=['Y'],intervention={}),5,time.perf_counter()+5)
  self.assertEqual(out['status'],'OK');self.assertEqual(out['values']['Y'],255.5);self.assertEqual(out['method'],'observed sample mean')
