"""Whole-node CSV tuple binding preserves the chosen graph and data semantics."""
import copy
import unittest
from unittest.mock import patch
import numpy as np
from causalengine import Editor
from causalengine.editor_engine import _categorical_feature_view

GRAPH={"nodes":[{"name":"X","family":"linear","dimension":1,"x":71,"y":39,"role":"covariate"},{"name":"A","family":"binary","dimension":1,"x":32,"y":110,"role":"treatment"},{"name":"Y","family":"linear","dimension":1,"x":160,"y":110,"role":"outcome"}],"edges":[["X","A"],["X","Y"],["A","Y"]]}
QUERY={"type":"interventional","summary":"mean_difference","targets":["Y"],"intervention":{"A":1},"reference":{"A":0},"Z":[],"max_seconds":5}

def upload(graph=None):
    return dict(copy.deepcopy(graph or GRAPH),columns=["c1","c2","t","out"],rows=[[i%3,(i//3)%2,i%2,3*(i%2)+i%3] for i in range(512)],mapping={"X":["c1","c2"],"A":"t","Y":"out"})

def estimate(editor,ready,graph=None,**options):
    return editor.request("estimate_data",dict(copy.deepcopy(graph or GRAPH),**QUERY,source="csv",data_id=ready["data_id"],binding_key=ready["binding_key"],**options))

class ClusterBindingTests(unittest.TestCase):
    def test_tuple_binding_preserves_graph_all_rows_members_and_no_scm(self):
        payload=upload();before=copy.deepcopy(payload);e=Editor()
        with patch("causalengine.editor_engine.build_scm",side_effect=AssertionError("No SCM")),patch("causalengine.editor_engine._reference",side_effect=AssertionError("No reference")):
            ready=e.request("load_data",payload)
            frame=e._uploaded["data"].copy(deep=True);schema=copy.deepcopy(e._uploaded["schema"])
            result=estimate(e,ready)
        self.assertEqual(payload,before)
        self.assertEqual(result["data_estimate"]["status"],"OK")
        self.assertEqual(result["cluster_adjustment"]["adjustment"],["X"])
        self.assertEqual(ready["bindings"]["X"]["members"],["c1","c2"])
        self.assertEqual(schema["X"]["shape"],(2,))
        np.testing.assert_array_equal(frame[schema["X"]["columns"]],np.array(payload["rows"])[:,:2])
        self.assertEqual(len(frame),512);self.assertTrue(frame.equals(e._uploaded["data"]))
        self.assertEqual(e._uploaded["schema"],schema);self.assertIsNone(e.model)
        self.assertNotIn("scm_reference",result)

    def test_binding_key_is_required_and_reordered_binding_expires(self):
        e=Editor();first=e.request("load_data",upload())
        base=dict(GRAPH,**QUERY,source="csv",data_id=first["data_id"])
        for key in (None,"stale"):
            with self.assertRaisesRegex(ValueError,"binding expired"):
                e.request("estimate_data",dict(base,binding_key=key))
        new=upload();new["mapping"]["X"].reverse();second=e.request("load_data",new)
        self.assertNotEqual(first["binding_key"],second["binding_key"])
        with self.assertRaisesRegex(ValueError,"binding expired"):
            e.request("estimate_data",dict(base,data_id=second["data_id"],binding_key=first["binding_key"]))

    def test_invalid_mapping_and_codebooks_fail_without_silent_coercion(self):
        cases=[]
        for members in ([],["c1","c1"],["c1","missing"],["c1","t"]):
            p=upload();p["mapping"]["X"]=members;cases.append(p)
        for book in ({"oops":"x"},{"nan":"x"},{"0":"a","0.0":"b","1":"c","2":"d"},{"0":"a","1":"b"}):
            p=upload();p["column_codebooks"]={"c1":book};cases.append(p)
        p=upload();p["column_types"]={"t":"continuous"};cases.append(p)
        for p in cases:
            with self.subTest(p=p.get("mapping")),self.assertRaises(ValueError):Editor().request("load_data",p)

    def test_mixed_nominal_cluster_is_lossless_temporary_full_onehot(self):
        p=upload();p["column_types"]={"c1":"categorical"};p["column_codebooks"]={"c1":{"0":"a","1":"b","2":"c"}}
        e=Editor();ready=e.request("load_data",p);raw=e._uploaded["data"].copy(deep=True);schema=copy.deepcopy(e._uploaded["schema"])
        with self.assertRaisesRegex(ValueError,"explicit one_hot"):estimate(e,ready)
        view,fit,info=_categorical_feature_view(raw,schema,dict(QUERY,categorical_encoding="one_hot"))
        self.assertTrue(raw.equals(e._uploaded["data"]));self.assertEqual(schema,e._uploaded["schema"])
        self.assertEqual(fit["X"]["shape"],(4,));self.assertEqual(len(view),512)
        encoded=list(info["encodings"].values())[0]
        np.testing.assert_array_equal(view[encoded["columns"]].to_numpy().argmax(axis=1),np.array(p["rows"])[:,0])
        self.assertEqual(estimate(e,ready,categorical_encoding="one_hot")["data_estimate"]["status"],"OK")

    def test_unsafe_frontdoor_posttreatment_and_irrelevant_cluster_abstain(self):
        for edges in ([["A","X"],["X","Y"]],[["A","Y"]],[["A","X"],["X","Y"],["U","A"],["U","Y"]]):
            graph=copy.deepcopy(GRAPH);graph["edges"]=edges
            if any("U" in pair for pair in edges):graph["nodes"].append({"name":"U","observed":False,"family":"linear"})
            e=Editor();ready=e.request("load_data",upload(graph))
            with patch("causalengine.editor_engine._estimate_mean",side_effect=AssertionError("No unsupported fallback")):
                result=estimate(e,ready,graph)
            self.assertEqual(result["data_estimate"]["status"],"UNSUPPORTED");self.assertNotIn("scm_reference",result)

    def test_clusters_cannot_be_actions_or_outcomes(self):
        for target in ("A","Y"):
            p=upload();other="X";p["mapping"][target]=["c1","c2"];p["mapping"][other]="t" if target=="A" else "out"
            p["mapping"]["A"]=["c1","c2"] if target=="A" else "t"
            p["mapping"]["Y"]=["c1","c2"] if target=="Y" else "out"
            if target=="A":
                p["nodes"][0]["variable_type"]="binary";p["column_types"]={"c1":"binary","c2":"binary"};p["rows"]=[[i%2,(i//2)%2,i%2,3*(i%2)] for i in range(512)]
            e=Editor();ready=e.request("load_data",p)
            if target=="A":
                with self.assertRaisesRegex(ValueError,"shape"):
                    estimate(e,ready,{"nodes":p["nodes"],"edges":p["edges"]})
                continue
            result=estimate(e,ready,{"nodes":p["nodes"],"edges":p["edges"]})
            self.assertEqual(result["data_estimate"]["status"],"UNSUPPORTED")
            self.assertIn("scalar",result["data_estimate"]["reason"])

if __name__=="__main__":unittest.main()
