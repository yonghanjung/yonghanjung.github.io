"""Supported baseline scores, failure boundaries and exact-source replay."""
import copy,csv,hashlib,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from causalengine import Editor,graph_examples
from causalengine.balancing_aipw import estimate_balancing_aipw
import causalengine.balancing_aipw as implementation

G={'nodes':[{'name':'X','family':'linear','dimension':1},{'name':'A','family':'binary','dimension':1},{'name':'Y','family':'linear','dimension':1}],'edges':[['X','A'],['X','Y'],['A','Y']]}
Q=dict(type='interventional',summary='mean_difference',targets=['Y'],intervention={'A':1},reference={'A':0},max_seconds=10)
def fixture(n=1024,p=3):
 rng=np.random.default_rng(41);z=rng.normal(size=(n,p));a=rng.binomial(1,.5,size=n);y=2*a+z.sum(axis=1)+rng.normal(size=n)
 return z,a,y

class BalancingAipwTests(unittest.TestCase):
 def test_raw_augmented_score_metadata_reverse_equal_and_no_mutation(self):
  z,a,y=fixture();old=[v.copy()for v in (z,a,y)]
  r=estimate_balancing_aipw(z,a,y,seed=53);self.assertEqual(r['status'],'OK',r)
  self.assertAlmostEqual(r['estimate'],r['diagnostics']['outcome_contrast_mean']+r['diagnostics']['augmentation_mean'],places=12)
  self.assertAlmostEqual(estimate_balancing_aipw(z,a,y,seed=53,intervention=0,reference=1)['estimate'],-r['estimate'],places=12)
  same=estimate_balancing_aipw(z,a,y,seed=53,reference=1);self.assertEqual(same['estimate'],0);self.assertFalse(same['estimation_details']['fit_performed'])
  self.assertAlmostEqual(r['estimation_details']['options']['xgboost']['reg_lambda'],1.)
  self.assertEqual(r['estimation_details']['options']['folds'],2)
  for f in r['diagnostics']['fold_details']:
   for arm in f['arms'].values():
    self.assertAlmostEqual(arm['training_weight_mass'],1,delta=1e-5);self.assertLessEqual(abs(arm['training_standardized_mu_residual']),1e-8)
  for value,original in zip((z,a,y),old):np.testing.assert_array_equal(value,original)

 def test_solver_failure_or_no_arm_no_overlap_deadline_abstains_without_value(self):
  z,a,y=fixture()
  with patch('causalengine.balancing_aipw.fit_xgboost_mean',side_effect=ValueError('intentional failure')):
   r=estimate_balancing_aipw(z,a,y);self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)
  r=estimate_balancing_aipw(z,np.ones(len(a)),y);self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)
  r=estimate_balancing_aipw(z,a,y,max_seconds=1e-10);self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)


 def test_minimum_variance_weight_constraints_and_actual_xgboost_settings(self):
  z,a,y=fixture();r=estimate_balancing_aipw(z,a,y)
  self.assertEqual(r['status'],'OK',r);self.assertIsNone(r['estimation_details']['options']['weight_cap'])
  self.assertEqual(r['estimation_details']['options']['weight_floor'],1e-8)
  for f in r['diagnostics']['fold_details']:
   for arm in f['arms'].values():
    self.assertGreaterEqual(arm['training_min_weight'],1e-8)
    self.assertLessEqual(abs(arm['training_mass_residual']),1e-8)
    self.assertLessEqual(abs(arm['training_standardized_mu_residual']),1e-8)
    self.assertEqual(arm['outcome_fit']['version'],'2.1.4')


 def test_invalid_arrays_nonfinite_domain_and_scalar_action(self):
  z,a,y=fixture()
  for cov,act,out in [(z[:-1],a,y),(z,a[:,None],y),(z,a,y[:,None]),(z,a+.25,y),(np.full_like(z,np.nan),a,y)]:
   with self.assertRaises(ValueError):estimate_balancing_aipw(cov,act,out)
  with self.assertRaises(ValueError):estimate_balancing_aipw(z,a,y,intervention=2)

 def test_csv_controls_result_no_scm_reference_and_stale_guard(self):
  z,a,y=fixture();cols=['assignment','score','v1','v2','v3'];rows=np.column_stack([a,y,z]).tolist();e=Editor()
  p=dict(copy.deepcopy(G),columns=cols,rows=rows,mapping={'A':'assignment','Y':'score','X':['v1','v2','v3']});before=copy.deepcopy(p)
  with patch('causalengine.editor_engine._reference',side_effect=AssertionError('No model truth')),patch('causalengine.editor_engine.build_scm',side_effect=AssertionError('No SCM')):
   ready=e.request('load_data',p);q=dict(G,**Q,source='csv',data_id=ready['data_id'],binding_key=ready['binding_key']);r=e.request('estimate_data',q)
   self.assertEqual(r['data_estimate']['status'],'OK',r);self.assertIn('AIPW',r['data_estimate']['method']);self.assertIsNone(e.model)
   shifted=copy.deepcopy(p)
   for row in shifted['rows']:row[1]+=4*row[0]
   new=e.request('load_data',shifted)
   with self.assertRaisesRegex(ValueError,'expired'):e.request('estimate_data',q)
   s=e.request('estimate_data',dict(q,data_id=new['data_id'],binding_key=new['binding_key']))
   self.assertAlmostEqual(s['data_estimate']['values']['Y']-r['data_estimate']['values']['Y'],4,delta=1e-6)
  self.assertEqual(p,before)

 def test_exact_source_csv_export_replays_recipe_and_all_options(self):
  z,a,y=fixture();e=Editor();mapping={'X':['v1','v2','v3'],'A':'assignment','Y':'score'};cols=['assignment','score','v1','v2','v3']
  ready=e.request('load_data',dict(G,columns=cols,rows=np.column_stack([a,y,z]).tolist(),mapping=mapping,data_seed=13))
  r=e.request('estimate_data',dict(G,**Q,source='csv',data_id=ready['data_id'],binding_key=ready['binding_key']))['data_estimate'];d=r['estimation_details'];source=Path(implementation.__file__).read_bytes()
  self.assertEqual(hashlib.sha256(source).hexdigest(),d['implementation']['sha256'])
  with tempfile.TemporaryDirectory(prefix='causalengine-replay-',dir='/tmp')as temp:
   root=Path(temp);(root/'balancing_aipw.py').write_bytes(source)
   with(root/'current.csv').open('w',newline='')as file:
    writer=csv.writer(file);writer.writerow(cols);writer.writerows(np.column_stack([a,y,z]).tolist())
   (root/'details.json').write_text(json.dumps(d))
   script='''import csv,json,numpy as np
from balancing_aipw import estimate_balancing_aipw
D=json.load(open('details.json'));I=D['inputs'];O=D['options'];R=list(csv.DictReader(open('current.csv')))
Z=np.column_stack([[(float(r[c['column']])==c['equals'])if'equals'in c else float(r[c['column']])for r in R]for c in I['covariates']]).astype(float) if I['covariates'] else np.empty((len(R),0))
A=np.array([float(r[I['treatment']])for r in R]);Y=np.array([float(r[I['outcome']])for r in R])
print(json.dumps(estimate_balancing_aipw(Z,A,Y,**{k:O[k]for k in ('seed','intervention','reference','max_seconds')})))
'''
   (root/'replay.py').write_text(script)
   out=json.loads(subprocess.check_output([sys.executable,str(root/'replay.py')],cwd=root,text=True))
  self.assertEqual(out['status'],'OK');self.assertAlmostEqual(out['estimate'],r['values']['Y'],places=12)
  self.assertEqual(out['diagnostics'],r['diagnostics'])

 def test_explicit_legacy_only_and_invalid_selector(self):
  z,a,y=fixture();e=Editor();columns=['A','Y','x1','x2','x3']
  ready=e.request('load_data',dict(G,columns=columns,rows=np.column_stack([a,y,z]).tolist(),mapping={'A':'A','Y':'Y','X':['x1','x2','x3']}))
  q=dict(G,**Q,source='csv',data_id=ready['data_id'],binding_key=ready['binding_key'])
  default=e.request('estimate_data',q)['data_estimate'];self.assertEqual(default['estimation_details']['requested_method'],'auto')
  with patch('causalengine.balancing_aipw.estimate_balancing_aipw',side_effect=AssertionError('No AIPW when explicitly legacy')):
   old=e.request('estimate_data',dict(q,estimation_method='legacy_knn'))['data_estimate']
  self.assertEqual(old['status'],'OK');self.assertEqual(old['estimation_details']['requested_method'],'legacy_knn')
  self.assertEqual(old['estimation_details']['method_id'],'legacy_graph_estimator');self.assertEqual(default['estimation_details']['method_id'],'minimum_variance_aipw_v1')
  with self.assertRaisesRegex(ValueError,'estimation_method'):e.request('estimate_data',dict(q,estimation_method='unknown'))

 def test_pasted_source_exec_without_file_computes_and_marks_sha_unavailable(self):
  namespace={'__name__':'pasted_estimator'};exec(Path(implementation.__file__).read_text(),namespace)
  z,a,y=fixture();r=namespace['estimate_balancing_aipw'](z,a,y,seed=53)
  self.assertEqual(r['status'],'OK');self.assertIsNone(r['estimation_details']['implementation']['sha256'])
  self.assertAlmostEqual(r['estimate'],estimate_balancing_aipw(z,a,y,seed=53)['estimate'],places=12)

 def test_frontdoor_and_continuous_treatment_keep_actual_legacy_method(self):
  g=copy.deepcopy(G);g['nodes'][1]['family']='linear';e=Editor();b=e.request('build',dict(g,model_seed=7));s=e.request('sample',dict(token=b['token'],n=512,data_seed=5))
  with patch('causalengine.editor_engine._estimate_mean',return_value={'status':'OK','method':'legacy-test','values':{'Y':1}})as old:
   r=e.request('estimate_data',dict(g,**Q,source='random',token=b['token'],sample_id=s['sample_id']))
  self.assertTrue(old.called);self.assertEqual(r['data_estimate']['estimation_details']['method_id'],'legacy_graph_estimator')
  fd={'nodes':[{'name':'U','observed':False},{'name':'A','family':'binary'},{'name':'M'},{'name':'Y'}],'edges':[['U','A'],['U','Y'],['A','M'],['M','Y']]};e=Editor();b=e.request('build',dict(fd,model_seed=7));s=e.request('sample',dict(token=b['token'],n=512,data_seed=5))
  with patch('causalengine.balancing_aipw.estimate_balancing_aipw',side_effect=AssertionError('No FD AIPW')):
   r=e.request('estimate_data',dict(fd,**Q,source='random',token=b['token'],sample_id=s['sample_id']))
  self.assertEqual(r['data_estimate']['estimation_details']['method_id'],'legacy_graph_estimator')

if __name__=='__main__':unittest.main()
