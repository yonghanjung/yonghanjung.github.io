"""Selected baseline scores, necessary nuisance fits and exact-data replay."""
import copy, csv, json, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from causalengine import Editor
import causalengine.balancing_aipw as core

G={'nodes':[{'name':'X','family':'linear','dimension':1},{'name':'A','family':'binary','dimension':1},{'name':'Y','family':'linear','dimension':1}],'edges':[['X','A'],['X','Y'],['A','Y']]}
Q=dict(type='interventional',summary='mean_difference',targets=['Y'],intervention={'A':1},reference={'A':0},max_seconds=10)
METHODS=('aipw','outcome_regression','ipw')
def fixture():
 rng=np.random.default_rng(41);z=rng.normal(size=(1024,3));a=rng.binomial(1,.5,size=1024);y=2*a+z.sum(axis=1)+rng.normal(size=1024)
 return z,a,y

def manual_scores(z,a,y,seed):
 """Independently form the three requested n-normalized scores from fitted arms."""
 n=len(a);fold=np.empty(n,int);rng=np.random.default_rng(seed)
 for arm in (0,1):
  ids=np.flatnonzero(a==arm);fold[rng.permutation(ids)]=np.arange(len(ids))%2
 m=np.empty((n,2));w=np.empty((n,2))
 for k in (0,1):
  t,v=fold!=k,fold==k;sd=z[t].std(0);sd=np.where(sd>1e-12,sd,1)
  s=(z-z[t].mean(0))/sd;B=np.column_stack([s,s*s]);sd=B[t].std(0);sd=np.where(sd>1e-12,sd,1);B=(B-B[t].mean(0))/sd
  for arm in (0,1):
   armrows=t&(a==arm);ba=B[armrows];ya=y[armrows];center=ba.mean(0);my=ya.mean();x=ba-center
   beta=np.linalg.solve(x.T@x/len(ba)+.001*np.eye(B.shape[1]),x.T@(ya-my)/len(ba));m[v,arm]=my+(B[v]-center)@beta
   phi=np.column_stack([np.ones(t.sum()),B[t]]);sel=a[t]==arm
   def loss(theta):
    logits=phi@theta;alpha=1+19*expit(logits)
    value=(19*np.logaddexp(0,logits[sel]).sum()-logits[~sel].sum())/len(phi)+.005*(theta[1:]@theta[1:])
    gradient=((sel*alpha-1)[:,None]*phi).mean(0);gradient[1:]+=.01*theta[1:]
    return value,gradient
   init=np.zeros(phi.shape[1]);inv=len(phi)/sel.sum();init[0]=np.log((inv-1)/(20-inv))
   fit=minimize(loss,init,jac=True,method='L-BFGS-B',options=dict(maxiter=400,ftol=1e-12,gtol=1e-7));assert fit.success
   w[v,arm]=1+19*expit(fit.x[0]+B[v]@fit.x[1:])
 return dict(outcome_regression=m[:,1]-m[:,0],ipw=(a==1)*w[:,1]*y-(a==0)*w[:,0]*y,
             aipw=m[:,1]-m[:,0]+(a==1)*w[:,1]*(y-m[:,1])-(a==0)*w[:,0]*(y-m[:,0]))

class ThreeEstimatorTests(unittest.TestCase):
 def test_selected_scores_equal_independent_manual_raw_means(self):
  z,a,y=fixture();scores=manual_scores(z,a,y,53)
  for method in METHODS:
   r=core.estimate_balancing_aipw(z,a,y,seed=53,estimator=method);self.assertEqual(r['status'],'OK',r)
   self.assertAlmostEqual(r['estimate'],scores[method].mean(),places=9)
   self.assertEqual(r['estimation_details']['options']['estimator'],method)
   expected={'outcome':0 if method=='ipw' else 4,'weights':0 if method=='outcome_regression' else 4}
   self.assertEqual(r['estimation_details']['nuisance']['fit_calls'],expected)
   self.assertEqual(r['estimation_details']['nuisance']['fit_completed'],expected)
   self.assertEqual(r['estimation_details']['nuisance']['fitted'],{'outcome':method!='ipw','weights':method!='outcome_regression'})

 def test_irrelevant_fit_is_never_called_and_irrelevant_options_unused(self):
  z,a,y=fixture()
  with patch('causalengine.balancing_aipw.minimize',side_effect=AssertionError('OR must not fit weights')):
   r=core.estimate_balancing_aipw(z,a,y,estimator='outcome_regression')
  self.assertEqual(r['status'],'OK');self.assertIsNone(r['estimation_details']['options']['weight_cap']);self.assertIsNone(r['estimation_details']['options']['balance_penalty'])
  self.assertNotIn('heldout_ess',r['diagnostics']['fold_details'][0]['arms']['0'])
  with patch('causalengine.balancing_aipw.np.linalg.solve',side_effect=AssertionError('IPW must not fit outcomes')):
   r=core.estimate_balancing_aipw(z,a,y,estimator='ipw')
  self.assertEqual(r['status'],'OK');self.assertIsNone(r['estimation_details']['options']['ridge'])
  self.assertNotIn('train_outcome_rmse',r['diagnostics']['fold_details'][0]['arms']['0'])

 def test_or_does_not_run_weight_feasibility_gate_but_weight_methods_do(self):
  n=5000;a=np.r_[np.ones(200),np.zeros(n-200)];z=np.linspace(-1,1,n)[:,None];y=2*a+z[:,0]
  r=core.estimate_balancing_aipw(z,a,y,estimator='outcome_regression');self.assertEqual(r['status'],'OK',r)
  for method in ('aipw','ipw'):
   r=core.estimate_balancing_aipw(z,a,y,estimator=method);self.assertEqual(r['status'],'UNKNOWN');self.assertTrue(r['reason'].startswith('WEIGHT_FEASIBILITY'));self.assertNotIn('estimate',r)

 def test_default_unchanged_reverse_equal_permutation_and_input_preservation(self):
  z,a,y=fixture();before=[v.copy()for v in (z,a,y)]
  default=core.estimate_balancing_aipw(z,a,y,seed=53);explicit=core.estimate_balancing_aipw(z,a,y,seed=53,estimator='aipw')
  self.assertEqual(default,explicit);self.assertAlmostEqual(default['estimate'],1.9658635463011167,places=10)
  for method in METHODS:
   r=core.estimate_balancing_aipw(z,a,y,seed=53,estimator=method)
   rev=core.estimate_balancing_aipw(z,a,y,seed=53,estimator=method,intervention=0,reference=1)
   self.assertEqual(rev['estimate'],-r['estimate'])
   reordered=core.estimate_balancing_aipw(z[:,[2,0,1]],a,y,seed=53,estimator=method)
   self.assertAlmostEqual(reordered['estimate'],r['estimate'],places=8)
   equal=core.estimate_balancing_aipw(z,a,y,estimator=method,intervention=1,reference=1)
   self.assertEqual(equal['estimate'],0);self.assertEqual(equal['estimation_details']['nuisance']['fit_calls'],{'outcome':0,'weights':0});self.assertEqual(equal['estimation_details']['nuisance']['fitted'],{'outcome':False,'weights':False})
  for old,new in zip(before,(z,a,y)):np.testing.assert_array_equal(old,new)

 def test_explicit_method_rejects_unsupported_graph_without_legacy_fallback(self):
  z,a,y=fixture();graph=copy.deepcopy(G);graph['nodes'][1]['family']='linear';editor=Editor()
  ready=editor.request('load_data',dict(graph,columns=['X','A','Y'],rows=np.column_stack([z[:,0],a,y]).tolist(),mapping={'X':'X','A':'A','Y':'Y'}))
  for method in METHODS:
   with patch('causalengine.editor_engine._estimate_mean',side_effect=AssertionError('No fallback')):
    r=editor.request('estimate_data',dict(graph,**Q,source='csv',data_id=ready['data_id'],estimation_method=method))['data_estimate']
   self.assertEqual(r['status'],'UNSUPPORTED');self.assertNotIn('values',r)
  with self.assertRaisesRegex(ValueError,'estimator'):core.estimate_balancing_aipw(z,a,y,estimator='not-a-method')

 def test_source_csv_replay_all_three_methods_and_actual_recipes(self):
  z,a,y=fixture();editor=Editor();cols=['assignment','score','v1','v2','v3'];rows=np.column_stack([a,y,z]).tolist()
  ready=editor.request('load_data',dict(G,columns=cols,rows=rows,mapping={'A':cols[0],'Y':cols[1],'X':cols[2:]},data_seed=13))
  responses=[editor.request('estimate_data',dict(G,**Q,source='csv',data_id=ready['data_id'],binding_key=ready['binding_key'],estimation_method=m))['data_estimate']for m in METHODS]
  with tempfile.TemporaryDirectory(prefix='causalengine-three-replay-',dir='/tmp')as folder:
   root=Path(folder);(root/'balancing_aipw.py').write_bytes(Path(core.__file__).read_bytes())
   with(root/'current.csv').open('w',newline='')as stream:
    writer=csv.writer(stream);writer.writerow(cols);writer.writerows(rows)
   (root/'details.json').write_text(json.dumps([r['estimation_details']for r in responses]))
   script='''import csv,json,numpy as np
from balancing_aipw import estimate_balancing_aipw
rows=list(csv.DictReader(open('current.csv')));results=[]
for d in json.load(open('details.json')):
 i,o=d['inputs'],d['options'];z=np.column_stack([[float(r[c['column']]) for r in rows]for c in i['covariates']]);a=np.array([float(r[i['treatment']])for r in rows]);y=np.array([float(r[i['outcome']])for r in rows])
 results.append(estimate_balancing_aipw(z,a,y,**{k:o[k]for k in ('seed','intervention','reference','max_seconds','estimator')}))
print(json.dumps(results))
'''
   (root/'replay.py').write_text(script);replays=json.loads(subprocess.check_output([sys.executable,str(root/'replay.py')],cwd=root,text=True))
  for expected,replay in zip(responses,replays):
   self.assertEqual(replay['status'],'OK');self.assertEqual(replay['estimate'],expected['values']['Y']);self.assertEqual(replay['diagnostics'],expected['diagnostics'])

if __name__=='__main__':unittest.main()
