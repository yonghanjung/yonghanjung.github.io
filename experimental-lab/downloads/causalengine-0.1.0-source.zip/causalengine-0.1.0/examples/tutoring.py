"""Simulated example; run after installing this source directory or wheel."""
import json
from causalengine.demo import run_demo
print(json.dumps(run_demo(), indent=2))
