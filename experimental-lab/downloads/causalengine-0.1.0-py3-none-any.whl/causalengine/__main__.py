"""Command-line demo and local browser app server."""
import argparse
import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
import json

def main():
    parser = argparse.ArgumentParser(prog="causalengine")
    commands = parser.add_subparsers(dest="command", required=True)
    demo = commands.add_parser("demo", help="Run a synthetic binary-action example and print JSON")
    demo.add_argument("--rows", type=int, default=512)
    demo.add_argument("--data-seed", type=int, default=5)
    serve = commands.add_parser("serve", help="Serve the bundled browser app locally")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8766)
    args = parser.parse_args()
    if args.command == "demo":
        from .demo import run_demo
        print(json.dumps(run_demo(args.rows, args.data_seed), indent=2, allow_nan=False))
    else:
        web = files("causalengine").joinpath("web")
        handler = functools.partial(SimpleHTTPRequestHandler, directory=str(web))
        with ThreadingHTTPServer((args.host, args.port), handler) as server:
            print(f"CausalEngine app: http://{args.host}:{args.port}/ (Ctrl+C to stop)", flush=True)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass

if __name__ == "__main__":
    main()
