"""A complete simulated example, using the upstream Editor request API."""
from .editor_engine import Editor

def run_demo(rows=512, data_seed=5):
    editor = Editor()
    built = editor.request("build", {
        "nodes": [
            {"name": "U", "observed": False, "dimension": 1, "family": ""},
            {"name": "X", "observed": True, "dimension": 1, "family": "linear"},
            {"name": "A", "observed": True, "dimension": 1, "family": "binary"},
            {"name": "Y", "observed": True, "dimension": 1, "family": "linear"},
        ],
        "edges": [["U", "A"], ["U", "X"], ["A", "Y"], ["X", "A"], ["X", "Y"]],
        "model_seed": 7, "noise": "normal",
    })
    sample = editor.request("sample", {"token": built["token"], "n": rows, "data_seed": data_seed})
    comparison = editor.request("compare", {
        "token": built["token"], "sample_id": sample["sample_id"],
        "type": "interventional", "targets": ["Y"],
        "intervention": {"A": 1}, "reference": {"A": 0},
        "evidence": {}, "summary": "mean_difference",
        "n": 2048, "data_seed": data_seed, "max_seconds": 10,
        "allow_continuous_extrapolation": True,
    })
    return {"example": "simulated tutoring support; not real school data",
            "rows": sample["shape"][0], "columns": sample["columns"],
            "preview": sample["rows"][:3], "comparison": comparison}
