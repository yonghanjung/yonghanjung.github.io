"""UCA-derived one-stage RN objective, conversion, guards and no leakage."""
import unittest
from unittest.mock import patch
import numpy as np
from scipy.optimize import nnls as actual_nnls
from causalengine.balancing_aipw import estimate_balancing_aipw,_fit_uca_ipw_ratio

def fixture(n=1024,p=2):
 rng=np.random.default_rng(41);x=rng.normal(size=(n,p));a=rng.binomial(1,.5,n);y=2*a+x.sum(1)+rng.normal(size=n);return x,a,y

def dictionary(train,selected,values,seed):
 x=np.tanh(train);v=np.tanh(values);pool=np.vstack([x[selected],x]);rng=np.random.default_rng(seed)
 if not x.shape[1]:return np.ones((len(values),1))
 centers=pool[rng.choice(len(pool),min(24,len(pool)),replace=False)];z=(v+1)/2
 distance=np.mean((v[:,None,:]-centers[None,:,:])**2,axis=2)
 return np.column_stack([np.ones(len(v)),z,1-z,z*z,(1-z)**2,np.exp(-distance/.35)])

class UcaIpwTests(unittest.TestCase):
 def test_quadratic_objective_gradient_psd_and_actual_ratio_conversion(self):
  x,a,_=fixture(400,2);train=x[:300];selected=a[:300]==1;evaluation=x[300:];seed=211
  phi=dictionary(train,selected,train[selected],seed);target=dictionary(train,selected,train,seed)
  gram=phi.T@phi/len(phi)+.002*np.eye(phi.shape[1]);moment=target.mean(0);fitted=[]
  def verify(matrix,response,**kwargs):
   np.testing.assert_allclose(matrix.T@matrix,gram,atol=1e-12)
   np.testing.assert_allclose(matrix.T@response,moment,atol=1e-12)
   self.assertEqual(kwargs['maxiter'],3*len(moment));self.assertGreaterEqual(np.linalg.eigvalsh(gram).min(),.002-1e-12)
   result=actual_nnls(matrix,response,**kwargs);fitted.append(result[0]);return result
  with patch('causalengine.balancing_aipw.nnls',side_effect=verify):ta,ea,d=_fit_uca_ipw_ratio(train,selected,evaluation,seed,lambda:None)
  raw=phi@fitted[-1];scale=np.clip(raw,.01,50).mean();pi=selected.mean()
  np.testing.assert_allclose(ta,np.clip(raw,.01,50)/scale/pi,atol=1e-12)
  np.testing.assert_allclose(ea,np.clip(dictionary(train,selected,evaluation,seed)@fitted[-1],.01,50)/scale/pi,atol=1e-12)
  self.assertAlmostEqual((ta*pi).mean(),1,places=12);self.assertAlmostEqual(d['actual_inverse_weight_upper'],50/scale/pi)
  self.assertLessEqual(d['projected_kkt_residual'],1e-4);self.assertIsNone(d['iterations']);self.assertEqual(d['solver_maxiter'],3*len(moment))
  coef=fitted[-1];self.assertAlmostEqual(d['objective'],.5*coef@gram@coef-moment@coef,places=12)
  self.assertAlmostEqual(d['projected_kkt_residual'],float(np.max(np.abs(coef-np.maximum(0,coef-(gram@coef-moment))))),places=12)

 def test_heldout_rows_cannot_change_training_fit_or_normalization(self):
  x,a,_=fixture(400,2);ta,wa,d=_fit_uca_ipw_ratio(x[:300],a[:300]==1,x[300:],7,lambda:None)
  other_train,other_w,other_d=_fit_uca_ipw_ratio(x[:300],a[:300]==1,np.full_like(x[300:],1e6),7,lambda:None)
  np.testing.assert_array_equal(ta,other_train)
  for key in ['ratio_normalizer','training_arm_prevalence','training_raw_ratio_max_balance','training_post_ratio_max_balance','ratio_center_seed','projected_kkt_residual']:
   self.assertEqual(d[key],other_d[key])
  self.assertFalse(np.array_equal(wa,other_w))

 def test_no_outcome_learning_and_raw_score_linearity(self):
  x,a,y=fixture();first=estimate_balancing_aipw(x,a,y,seed=53,estimator='ipw');second=estimate_balancing_aipw(x,a,2*y,seed=53,estimator='ipw')
  self.assertEqual(first['status'],'OK',first);self.assertEqual(second['status'],'OK',second);self.assertEqual(second['estimate'],2*first['estimate'])
  self.assertEqual(first['diagnostics']['fold_details'],second['diagnostics']['fold_details'])
  self.assertEqual(first['estimation_details']['nuisance']['fit_calls'],{'outcome':0,'weights':4})
  self.assertEqual(first['estimation_details']['method_id'],'uca_balancing_ipw_v1');self.assertIsNone(first['estimation_details']['options']['weight_cap'])

 def test_failed_solver_keeps_diagnostic_and_no_partial_value(self):
  x,a,y=fixture()
  with patch('causalengine.balancing_aipw.nnls',side_effect=RuntimeError('intentional solver failure')):r=estimate_balancing_aipw(x,a,y,estimator='ipw')
  self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)
  arm=r['diagnostics']['fold_details'][0]['arms']['0'];self.assertFalse(arm['solver_success']);self.assertIn('projected_kkt_residual',arm);self.assertEqual(arm['solver_message'],'intentional solver failure')

 def test_true_empty_or_separated_support_and_deadline_abstain(self):
  x,a,y=fixture()
  for cov,act in [(x,np.zeros(len(a))),(np.where(x[:,[0]]>0,1.,-1.),(x[:,0]>0).astype(int))]:
   r=estimate_balancing_aipw(cov,act,y,estimator='ipw');self.assertEqual(r['status'],'UNKNOWN',r);self.assertNotIn('estimate',r)
  r=estimate_balancing_aipw(x,a,y,estimator='ipw',max_seconds=1e-10);self.assertEqual(r['status'],'UNKNOWN');self.assertNotIn('estimate',r)

if __name__=='__main__':unittest.main()
