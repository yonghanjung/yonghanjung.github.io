"""Random baseline vectors use real components and one guarded public snapshot."""
import copy
import unittest
from unittest.mock import patch
import numpy as np
from causalengine import Editor,analyze,build_scm

G={'nodes':[{'name':'X','family':'linear','dimension':1,'x':320,'y':40},{'name':'A','family':'binary','dimension':1,'x':160,'y':190},{'name':'Y','family':'linear','dimension':1,'x':480,'y':190}],'edges':[['X','A'],['X','Y'],['A','Y']]}
Q={'source':'random','type':'interventional','summary':'mean_difference','targets':['Y'],'intervention':{'A':1},'reference':{'A':0},'Z':[],'max_seconds':10}
def start(p,graph=None,members=None):
 graph=copy.deepcopy(graph or G);payload=dict(graph,model_seed=7,noise='normal',random_cluster_sizes={'X':p})
 if members is not None:payload['random_cluster_members']={'X':members}
 before=copy.deepcopy(payload);e=Editor();built=e.request('build',payload);assert payload==before
 return e,graph,built

def sample(e,b,seed=5,n=512):return e.request('sample',dict(token=b['token'],random_key=b['random_key'],n=n,data_seed=seed))
def request(e,g,b,s,action,**extra):return e.request(action,dict(g,**Q,token=b['token'],sample_id=s['sample_id'],random_key=b['random_key'],**extra))

class RandomClusterTests(unittest.TestCase):
 def assert_estimate_or_fixed_weight_gate(self, result, p):
  if p==1:
   self.assertEqual(result['status'],'OK')
  elif result['status']!='OK':
   self.assertEqual(result['status'],'UNKNOWN');self.assertTrue(result['reason'].startswith('WEAK_OVERLAP:'))
   self.assertNotIn('values',result);self.assertEqual(result['diagnostics']['covariate_coordinates'],p)
   self.assertEqual(result['estimation_details']['method_id'],'balancing_aipw_v1')
   self.assertTrue(result['diagnostics']['fold_details'])

 def test_real_1_25_50_components_estimate_reference_and_snapshot(self):
  for p in (1,25,50):
   with self.subTest(dimension=p):
    e,g,b=start(p);s=sample(e,b);before=e._sample.copy(deep=True);metadata=copy.deepcopy(e.model.describe())
    self.assertEqual(s['shape'],[512,p+2]);self.assertEqual(len(s['random_bindings']['X']['members']),p)
    self.assertEqual(e.model._variables['X']['shape'],()if p==1 else(p,));self.assertEqual([n['dimension']for n in g['nodes']],[1,1,1])
    self.assertEqual(len(set(s['columns'])),p+2)
    self.assertTrue((before[s['random_bindings']['X']['members']].std().to_numpy()>0).all())
    estimate=request(e,g,b,s,'estimate_data');ref=request(e,g,b,s,'sample_reference',n=512)
    self.assert_estimate_or_fixed_weight_gate(estimate['data_estimate'],p);self.assertEqual(ref['model_reference']['status'],'OK')
    
    if estimate['data_estimate']['status']=='OK':self.assertTrue(np.isfinite(estimate['data_estimate']['values']['Y']))
    self.assertTrue(np.isfinite(ref['model_reference']['values']['Y']))
    self.assertEqual(estimate['cluster_adjustment']['adjustment'],['X']);self.assertEqual(estimate['random_bindings'],s['random_bindings'])
    self.assertEqual(ref['random_key'],s['random_key']);self.assertEqual(ref['sample_id'],s['sample_id'])
    self.assertTrue(before.equals(e._sample));self.assertEqual(metadata,e.model.describe())
    if p>1:self.assertEqual(ref['reference_kind'],'monte_carlo_model_mean');self.assertIn('Y',ref['model_reference']['standard_errors'])
    else:self.assertEqual(ref['reference_kind'],'exact_model_mean');self.assertEqual(s['columns'],['X','A','Y'])

 def test_same_seed_csv_and_model_reuse_stale_samples_keys_graph(self):
  e,g,b=start(50);a=sample(e,b);other=sample(e,b,seed=6);again=sample(e,b,seed=5)
  self.assertEqual(a['csv'],again['csv']);self.assertNotEqual(a['csv'],other['csv']);self.assertEqual(b['token'],e.token)
  with self.assertRaisesRegex(ValueError,'sample expired'):request(e,g,b,a,'estimate_data')
  for action in ('estimate_data','sample_reference'):
   payload=dict(g,**Q,token=b['token'],sample_id=again['sample_id'],random_key='stale')
   with self.subTest(action=action),self.assertRaisesRegex(ValueError,'configuration expired'):e.request(action,payload)
   with self.assertRaisesRegex(ValueError,'graph'):e.request(action,dict(payload,random_key=b['random_key'],edges=[]))
  with self.assertRaisesRegex(ValueError,'configuration expired'):e.request('sample',dict(token=b['token'],n=512,data_seed=5))
  c=start(25)[2];self.assertNotEqual(c['random_key'],b['random_key'])

 def test_invalid_dimensions_members_domains_and_physical_limits(self):
  for p in (0,51,True,25.0):
   with self.subTest(p=p),self.assertRaises(ValueError):start(p)
  for members in (['a'],['a']*25,['A']+[f'x{i}'for i in range(24)]):
   with self.subTest(members=members[:2]),self.assertRaises(ValueError):start(25,members=members)
  for change in ({'family':'binary'},{'family':'random'},{'dimension':2},{'variable_type':'categorical'}):
   g=copy.deepcopy(G);g['nodes'][0].update(change)
   with self.subTest(change=change),self.assertRaises(ValueError):start(25,graph=g)
  g=copy.deepcopy(G);g['nodes'].append({'name':'C','family':'linear','dimension':1})
  with self.assertRaisesRegex(ValueError,'100 distinct'):Editor().request('build',dict(g,random_cluster_sizes={'X':50,'C':50}))
  with self.assertRaises(ValueError):build_scm(dict(G,nodes=[dict(n,dimension=50)if n['name']=='X'else n for n in G['nodes']]))
  with self.assertRaises(ValueError):analyze(dict(G,nodes=[dict(n,dimension=50)if n['name']=='X'else n for n in G['nodes']],X=['A'],Y=['Y']))

 def test_role_guard_prevents_posttreatment_vector_estimate_and_truth(self):
  graph=copy.deepcopy(G);graph['edges']=[['A','X'],['X','Y']]
  e,g,b=start(25,graph);s=sample(e,b)
  with patch('causalengine.editor_engine._estimate_mean',side_effect=AssertionError('No unsafe estimator')),patch('causalengine.editor_engine._paired_vector_reference',side_effect=AssertionError('No unsafe truth')):
   for action in ('estimate_data','sample_reference'):
    out=request(e,g,b,s,action)
    self.assertEqual((out.get('data_estimate')or out.get('model_reference'))['status'],'UNSUPPORTED')

 def test_shape_corruption_and_reference_allocation_deadline_fail_closed(self):
  e,g,b=start(50);s=sample(e,b)
  with patch.object(e.model,'sample_interventional',side_effect=AssertionError('No overbudget allocation')):
   out=request(e,g,b,s,'sample_reference',n=10000);self.assertEqual(out['model_reference']['status'],'UNSUPPORTED');self.assertNotIn('values',out['model_reference'])
  out=e.request('sample_reference',dict(g,**dict(Q,max_seconds=1e-10),token=b['token'],sample_id=s['sample_id'],random_key=b['random_key'],n=512))
  self.assertEqual(out['reference_kind'],'unavailable');self.assertNotIn('values',out['model_reference'])
  e.model._variables['X']['shape']=(49,)
  with self.assertRaisesRegex(ValueError,'shape'):request(e,g,b,s,'estimate_data')

 def test_native_inspect_parameter_apply_preserves_50_members(self):
  e,g,b=start(50);s=sample(e,b)
  inspected=e.request('inspect',dict(token=b['token'],name='X'));self.assertIn('source',inspected['function'])
  params=copy.deepcopy(e.model.equations['X']._scm_parameters);params['coordinates'][0]['intercept']+=0.5
  updated=e.request('update',dict(token=b['token'],name='X',parameters=params))
  self.assertEqual(e.model._variables['X']['shape'],(50,));self.assertEqual(e.model._variables['X']['columns'],s['random_bindings']['X']['members'])
  self.assertEqual(updated['random_key'],e._random_key);self.assertEqual(updated['random_bindings'],s['random_bindings']);self.assertIsNone(e._sample)
  with self.assertRaisesRegex(ValueError,'continuous mechanism'):e.request('update',dict(token=updated['token'],name='X',family='binary'))
  b=dict(b,token=updated['token'],random_key=updated['random_key']);new=sample(e,b);self.assertEqual(new['shape'],[512,52]);self.assert_estimate_or_fixed_weight_gate(request(e,g,b,new,'estimate_data')['data_estimate'],50)

 def test_type_changing_apply_resumes_and_failure_preserves_full_state(self):
  for name,family in [('Y','binary'),('A','linear')]:
   with self.subTest(name=name):
    e,g,b=start(25);old_sample=sample(e,b);before=copy.deepcopy(g)
    updated=e.request('update',dict(token=b['token'],name=name,family=family))
    self.assertNotEqual(updated['random_key'],b['random_key']);self.assertEqual(g,before)
    node=next(n for n in g['nodes']if n['name']==name);node.update(family=family,variable_type=e.model._variables[name]['variable_type'])
    newbuild=dict(b,token=updated['token'],random_key=updated['random_key']);fresh=sample(e,newbuild)
    self.assert_estimate_or_fixed_weight_gate(request(e,g,newbuild,fresh,'estimate_data')['data_estimate'],25)
    self.assertEqual(request(e,g,newbuild,fresh,'sample_reference',n=512)['model_reference']['status'],'OK')
    saved=e._sample.copy(deep=True);state=(e.token,e._random_key,e._random_public_key,copy.deepcopy(e.model.describe()),copy.deepcopy(e._random_bindings))
    with self.assertRaisesRegex(ValueError,'continuous mechanism'):e.request('update',dict(token=e.token,name='X',family='binary'))
    self.assertEqual(state,(e.token,e._random_key,e._random_public_key,e.model.describe(),e._random_bindings));self.assertTrue(saved.equals(e._sample))

 def test_deadline_after_aggregation_never_exposes_partial_value(self):
  e,g,b=start(25);s=sample(e,b)
  with patch('causalengine.editor_engine.perf_counter',side_effect=[0,0,0,0,11]):
   out=request(e,g,b,s,'sample_reference',n=512)
  self.assertEqual(out['model_reference']['status'],'UNKNOWN');self.assertNotIn('values',out['model_reference']);self.assertEqual(out['reference_kind'],'unavailable')

if __name__=='__main__':unittest.main()
